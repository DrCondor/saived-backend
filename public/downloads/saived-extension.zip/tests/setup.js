/**
 * Jest setup for SAIVED Extension tests
 * Mocks Chrome/Firefox extension APIs
 */

// Mock chrome.storage API
const mockStorage = {
  local: {
    _data: {},
    get: jest.fn((keys) => {
      if (typeof keys === 'string') {
        return Promise.resolve({ [keys]: mockStorage.local._data[keys] });
      }
      if (Array.isArray(keys)) {
        const result = {};
        keys.forEach((k) => {
          if (k in mockStorage.local._data) {
            result[k] = mockStorage.local._data[k];
          }
        });
        return Promise.resolve(result);
      }
      return Promise.resolve({ ...mockStorage.local._data });
    }),
    set: jest.fn((items) => {
      Object.assign(mockStorage.local._data, items);
      return Promise.resolve();
    }),
    remove: jest.fn((keys) => {
      const keysArray = Array.isArray(keys) ? keys : [keys];
      keysArray.forEach((k) => delete mockStorage.local._data[k]);
      return Promise.resolve();
    }),
    clear: jest.fn(() => {
      mockStorage.local._data = {};
      return Promise.resolve();
    }),
  },
};

// Mock chrome.tabs API
const mockTabs = {
  query: jest.fn(() =>
    Promise.resolve([
      {
        id: 1,
        url: 'https://example.com/product/123',
        title: 'Test Product Page',
      },
    ])
  ),
  sendMessage: jest.fn(() => Promise.resolve({ ok: true })),
  create: jest.fn(() => Promise.resolve({ id: 2 })),
};

// Mock chrome.runtime API
const mockRuntime = {
  lastError: null,
  onMessage: {
    addListener: jest.fn(),
    removeListener: jest.fn(),
  },
  sendMessage: jest.fn(() => Promise.resolve()),
  getURL: jest.fn((path) => `chrome-extension://mock-id/${path}`),
};

// Mock chrome.scripting API (MV3)
const mockScripting = {
  executeScript: jest.fn(() => Promise.resolve([{ result: {} }])),
};

// Complete chrome API mock
global.chrome = {
  storage: mockStorage,
  tabs: mockTabs,
  runtime: mockRuntime,
  scripting: mockScripting,
};

// Firefox compatibility (browser API)
global.browser = global.chrome;

// Mock window.location for tests
delete window.location;
window.location = {
  href: 'https://example.com/product/123',
  hostname: 'example.com',
  pathname: '/product/123',
  origin: 'https://example.com',
};

// Mock fetch API
global.fetch = jest.fn(() =>
  Promise.resolve({
    ok: true,
    json: () => Promise.resolve({}),
    text: () => Promise.resolve(''),
  })
);

// Reset mocks before each test
beforeEach(() => {
  jest.clearAllMocks();
  mockStorage.local._data = {};
  global.fetch.mockClear();
});

// Export mocks for direct access in tests
module.exports = {
  mockStorage,
  mockTabs,
  mockRuntime,
  mockScripting,
};
