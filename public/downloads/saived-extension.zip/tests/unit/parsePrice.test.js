/**
 * Tests for parsePrice() - International Price Parser
 *
 * Covers:
 * - Polish/European formats (comma as decimal)
 * - US/UK formats (dot as decimal)
 * - German formats (dot as thousands, comma as decimal)
 * - Formats with currency symbols
 * - Edge cases and error handling
 */

const parsePrice = require('../../lib/parsePrice');

describe('parsePrice', () => {
  // ============================================================
  // NULL AND INVALID INPUT
  // ============================================================
  describe('null and invalid input', () => {
    test('returns null for null input', () => {
      expect(parsePrice(null)).toBeNull();
    });

    test('returns null for undefined input', () => {
      expect(parsePrice(undefined)).toBeNull();
    });

    test('returns null for empty string', () => {
      expect(parsePrice('')).toBeNull();
    });

    test('returns null for whitespace only', () => {
      expect(parsePrice('   ')).toBeNull();
    });

    test('returns null for non-numeric text', () => {
      expect(parsePrice('no price here')).toBeNull();
    });

    test('returns null for only currency symbols', () => {
      expect(parsePrice('zł')).toBeNull();
    });
  });

  // ============================================================
  // SIMPLE INTEGER PRICES
  // ============================================================
  describe('simple integer prices', () => {
    test('parses "100" as 100', () => {
      expect(parsePrice('100')).toBe(100);
    });

    test('parses "1234" as 1234', () => {
      expect(parsePrice('1234')).toBe(1234);
    });

    test('parses "0" as 0', () => {
      expect(parsePrice('0')).toBe(0);
    });

    test('parses "999999" as 999999', () => {
      expect(parsePrice('999999')).toBe(999999);
    });
  });

  // ============================================================
  // POLISH/EUROPEAN FORMAT (comma as decimal)
  // ============================================================
  describe('Polish/European format (comma as decimal)', () => {
    test('parses "329,99" as 329.99', () => {
      expect(parsePrice('329,99')).toBe(329.99);
    });

    test('parses "99,00" as 99', () => {
      expect(parsePrice('99,00')).toBe(99);
    });

    test('parses "1,50" as 1.5', () => {
      expect(parsePrice('1,50')).toBe(1.5);
    });

    test('parses "0,99" as 0.99', () => {
      expect(parsePrice('0,99')).toBe(0.99);
    });

    test('parses "1234,56" as 1234.56', () => {
      expect(parsePrice('1234,56')).toBe(1234.56);
    });
  });

  // ============================================================
  // US/UK FORMAT (dot as decimal)
  // ============================================================
  describe('US/UK format (dot as decimal)', () => {
    test('parses "329.99" as 329.99', () => {
      expect(parsePrice('329.99')).toBe(329.99);
    });

    test('parses "99.00" as 99', () => {
      expect(parsePrice('99.00')).toBe(99);
    });

    test('parses "1.50" as 1.5', () => {
      expect(parsePrice('1.50')).toBe(1.5);
    });

    test('parses "0.99" as 0.99', () => {
      expect(parsePrice('0.99')).toBe(0.99);
    });

    test('parses "1234.56" as 1234.56', () => {
      expect(parsePrice('1234.56')).toBe(1234.56);
    });
  });

  // ============================================================
  // US FORMAT WITH THOUSANDS SEPARATOR (comma as thousands)
  // ============================================================
  describe('US format with thousands separator', () => {
    test('parses "4,790.00" as 4790 (ramaro.pl case)', () => {
      expect(parsePrice('4,790.00')).toBe(4790);
    });

    test('parses "1,234.56" as 1234.56', () => {
      expect(parsePrice('1,234.56')).toBe(1234.56);
    });

    test('parses "12,345.67" as 12345.67', () => {
      expect(parsePrice('12,345.67')).toBe(12345.67);
    });

    test('parses "123,456.78" as 123456.78', () => {
      expect(parsePrice('123,456.78')).toBe(123456.78);
    });

    test('parses "1,234,567.89" as 1234567.89', () => {
      expect(parsePrice('1,234,567.89')).toBe(1234567.89);
    });

    test('parses "10,000.00" as 10000', () => {
      expect(parsePrice('10,000.00')).toBe(10000);
    });
  });

  // ============================================================
  // GERMAN FORMAT (dot as thousands, comma as decimal)
  // ============================================================
  describe('German format (dot as thousands, comma as decimal)', () => {
    test('parses "4.790,00" as 4790', () => {
      expect(parsePrice('4.790,00')).toBe(4790);
    });

    test('parses "1.234,56" as 1234.56', () => {
      expect(parsePrice('1.234,56')).toBe(1234.56);
    });

    test('parses "12.345,67" as 12345.67', () => {
      expect(parsePrice('12.345,67')).toBe(12345.67);
    });

    test('parses "123.456,78" as 123456.78', () => {
      expect(parsePrice('123.456,78')).toBe(123456.78);
    });

    test('parses "1.234.567,89" as 1234567.89', () => {
      expect(parsePrice('1.234.567,89')).toBe(1234567.89);
    });

    test('parses "10.000,00" as 10000', () => {
      expect(parsePrice('10.000,00')).toBe(10000);
    });
  });

  // ============================================================
  // EUROPEAN FORMAT WITH SPACE THOUSANDS
  // ============================================================
  describe('European format with space thousands', () => {
    test('parses "4 790,00" as 4790', () => {
      expect(parsePrice('4 790,00')).toBe(4790);
    });

    test('parses "1 234,56" as 1234.56', () => {
      expect(parsePrice('1 234,56')).toBe(1234.56);
    });

    test('parses "12 345,67" as 12345.67', () => {
      expect(parsePrice('12 345,67')).toBe(12345.67);
    });

    test('parses "1 234 567,89" as 1234567.89', () => {
      expect(parsePrice('1 234 567,89')).toBe(1234567.89);
    });

    test('parses "1 234 567" as 1234567 (no decimal)', () => {
      expect(parsePrice('1 234 567')).toBe(1234567);
    });
  });

  // ============================================================
  // PRICES WITH POLISH CURRENCY (zł, PLN)
  // ============================================================
  describe('prices with Polish currency', () => {
    test('parses "329,99 zł" as 329.99', () => {
      expect(parsePrice('329,99 zł')).toBe(329.99);
    });

    test('parses "329,99zł" as 329.99 (no space)', () => {
      expect(parsePrice('329,99zł')).toBe(329.99);
    });

    test('parses "zł 329,99" as 329.99 (prefix)', () => {
      expect(parsePrice('zł 329,99')).toBe(329.99);
    });

    test('parses "4 790,00 zł" as 4790', () => {
      expect(parsePrice('4 790,00 zł')).toBe(4790);
    });

    test('parses "4,790.00 zł" as 4790 (US format with zł)', () => {
      expect(parsePrice('4,790.00 zł')).toBe(4790);
    });

    test('parses "329,99 PLN" as 329.99', () => {
      expect(parsePrice('329,99 PLN')).toBe(329.99);
    });

    test('parses "PLN 329,99" as 329.99 (prefix)', () => {
      expect(parsePrice('PLN 329,99')).toBe(329.99);
    });
  });

  // ============================================================
  // PRICES WITH OTHER CURRENCIES
  // ============================================================
  describe('prices with other currencies', () => {
    test('parses "$99.99" as 99.99', () => {
      expect(parsePrice('$99.99')).toBe(99.99);
    });

    test('parses "99.99$" as 99.99', () => {
      expect(parsePrice('99.99$')).toBe(99.99);
    });

    test('parses "€99,99" as 99.99', () => {
      expect(parsePrice('€99,99')).toBe(99.99);
    });

    test('parses "99,99€" as 99.99', () => {
      expect(parsePrice('99,99€')).toBe(99.99);
    });

    test('parses "£99.99" as 99.99', () => {
      expect(parsePrice('£99.99')).toBe(99.99);
    });

    test('parses "¥9999" as 9999', () => {
      expect(parsePrice('¥9999')).toBe(9999);
    });

    test('parses "₽4 790,00" as 4790 (Russian ruble)', () => {
      expect(parsePrice('₽4 790,00')).toBe(4790);
    });
  });

  // ============================================================
  // AMBIGUOUS SINGLE SEPARATOR CASES
  // ============================================================
  describe('ambiguous single separator cases', () => {
    test('parses "1,234" as 1234 (thousands, 3 digits after)', () => {
      expect(parsePrice('1,234')).toBe(1234);
    });

    test('parses "1.234" as 1234 (thousands, 3 digits after)', () => {
      expect(parsePrice('1.234')).toBe(1234);
    });

    test('parses "1,23" as 1.23 (decimal, 2 digits after)', () => {
      expect(parsePrice('1,23')).toBe(1.23);
    });

    test('parses "1.23" as 1.23 (decimal, 2 digits after)', () => {
      expect(parsePrice('1.23')).toBe(1.23);
    });

    test('parses "1,2" as 1.2 (decimal, 1 digit after)', () => {
      expect(parsePrice('1,2')).toBe(1.2);
    });

    test('parses "1.2" as 1.2 (decimal, 1 digit after)', () => {
      expect(parsePrice('1.2')).toBe(1.2);
    });
  });

  // ============================================================
  // MULTIPLE THOUSANDS SEPARATORS (NO DECIMAL)
  // ============================================================
  describe('multiple thousands separators without decimal', () => {
    test('parses "1,234,567" as 1234567 (US style)', () => {
      expect(parsePrice('1,234,567')).toBe(1234567);
    });

    test('parses "1.234.567" as 1234567 (German style)', () => {
      expect(parsePrice('1.234.567')).toBe(1234567);
    });

    test('parses "12,345,678" as 12345678', () => {
      expect(parsePrice('12,345,678')).toBe(12345678);
    });

    test('parses "12.345.678" as 12345678', () => {
      expect(parsePrice('12.345.678')).toBe(12345678);
    });
  });

  // ============================================================
  // EDGE CASES AND REAL-WORLD EXAMPLES
  // ============================================================
  describe('edge cases and real-world examples', () => {
    test('parses "Cena: 329,99 zł" with prefix text', () => {
      expect(parsePrice('Cena: 329,99 zł')).toBe(329.99);
    });

    test('parses "329,99 zł/szt." with suffix text', () => {
      expect(parsePrice('329,99 zł/szt.')).toBe(329.99);
    });

    test('parses "  329,99  " with extra whitespace', () => {
      expect(parsePrice('  329,99  ')).toBe(329.99);
    });

    test('parses price from HTML-like content "329,99&nbsp;zł"', () => {
      // Note: &nbsp; would be converted to space by browser
      expect(parsePrice('329,99 zł')).toBe(329.99);
    });

    test('handles very large prices "999.999.999,99"', () => {
      expect(parsePrice('999.999.999,99')).toBe(999999999.99);
    });

    test('handles very small prices "0,01"', () => {
      expect(parsePrice('0,01')).toBe(0.01);
    });

    test('handles prices with trailing zeros "100,00"', () => {
      expect(parsePrice('100,00')).toBe(100);
    });

    // Real ramaro.pl case that was failing
    test('handles ramaro.pl format "4,790.00 zł" correctly', () => {
      expect(parsePrice('4,790.00 zł')).toBe(4790);
    });

    // IKEA formats
    test('handles IKEA style "1 299,-" (Polish)', () => {
      // The dash is common in Polish pricing
      expect(parsePrice('1 299')).toBe(1299);
    });
  });

  // ============================================================
  // PRECISION AND ROUNDING
  // ============================================================
  describe('precision', () => {
    test('maintains precision for "123,456" (3 decimal places)', () => {
      // With 3 digits after comma, treated as thousands
      expect(parsePrice('123,456')).toBe(123456);
    });

    test('parses "99,9" as 99.9', () => {
      expect(parsePrice('99,9')).toBe(99.9);
    });

    test('parses "99,999" as 99999 (thousands)', () => {
      // 3 digits after comma = thousands separator
      expect(parsePrice('99,999')).toBe(99999);
    });
  });

  // ============================================================
  // MIXED/UNUSUAL FORMATS
  // ============================================================
  describe('unusual formats', () => {
    test('handles price in parentheses "(329,99)"', () => {
      expect(parsePrice('(329,99)')).toBe(329.99);
    });

    test('handles price with hyphen range "329-399" takes first', () => {
      // Should extract first number
      expect(parsePrice('329-399')).toBe(329);
    });

    test('handles "od 329,99 zł" (from price)', () => {
      expect(parsePrice('od 329,99 zł')).toBe(329.99);
    });
  });
});
