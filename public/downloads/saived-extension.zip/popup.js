const API_BASE_URL = "https://saived.ai";
const browserApi = typeof browser !== "undefined" ? browser : chrome;
const PRICE_PICKER_KEY = "saived_price_picker";

// ============ Token Management ============

async function getStoredToken() {
  const { apiToken } = await browserApi.storage.local.get(["apiToken"]);
  return apiToken || null;
}

async function saveToken(token) {
  await browserApi.storage.local.set({ apiToken: token });
}

async function clearToken() {
  await browserApi.storage.local.remove(["apiToken"]);
}

async function validateToken(token) {
  if (!token) return false;

  try {
    const res = await fetch(`${API_BASE_URL}/api/v1/projects`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return res.ok;
  } catch (e) {
    console.warn("[SAIVED] Token validation error:", e);
    return false;
  }
}

// ============ Screen Management ============

function showConfigScreen() {
  document.getElementById("config-screen").classList.add("active");
  document.getElementById("main-screen").classList.remove("active");
}

function showMainScreen() {
  document.getElementById("config-screen").classList.remove("active");
  document.getElementById("main-screen").classList.add("active");
}

// ============ Category Labels ============

const CATEGORY_LABELS = {
  meble: 'MEBLE',
  tkaniny: 'TKANINY',
  dekoracje: 'DEKORACJE',
  armatura_i_ceramika: 'ARMATURA I CERAMIKA',
  oswietlenie: 'OŚWIETLENIE',
  okladziny_scienne: 'OKŁADZINY ŚCIENNE',
  agd: 'AGD'
};

function getCategoryLabel(categoryId) {
  return CATEGORY_LABELS[categoryId] || categoryId?.toUpperCase() || 'BRAK';
}

// ============ Learned Selectors ============

async function fetchLearnedSelectors(domain, token) {
  if (!domain || !token) return {};

  try {
    const res = await fetch(
      `${API_BASE_URL}/api/v1/selectors?domain=${encodeURIComponent(domain)}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (!res.ok) {
      console.warn("[SAIVED] Failed to fetch learned selectors:", res.status);
      return {};
    }

    const data = await res.json();
    console.log("[SAIVED] Learned selectors for", domain, ":", data);
    return data.selectors || {};
  } catch (e) {
    console.warn("[SAIVED] Error fetching learned selectors:", e);
    return {};
  }
}

// ============ Learned Categories ============

async function fetchLearnedCategories(domain, token) {
  if (!domain || !token) return null;

  try {
    const res = await fetch(
      `${API_BASE_URL}/api/v1/categories?domain=${encodeURIComponent(domain)}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (!res.ok) {
      console.warn("[SAIVED] Failed to fetch learned categories:", res.status);
      return null;
    }

    const data = await res.json();
    console.log("[SAIVED] Learned categories for", domain, ":", data);
    return data;
  } catch (e) {
    console.warn("[SAIVED] Error fetching learned categories:", e);
    return null;
  }
}

// Track the suggested category globally for learning
let suggestedCategory = null;
let categoryConfidence = 0;

/**
 * Display category suggestions with smart merging.
 */
function displayCategorySuggestions(heuristicSuggestions, learnedCategories, categorySelect, pillsContainer, pillsWrapper) {
  let finalSuggestions = [...(heuristicSuggestions || [])];

  if (learnedCategories?.categories && learnedCategories.categories.length > 0 && finalSuggestions.length > 0) {
    for (const learned of learnedCategories.categories) {
      if (learned.confidence < 0.3) continue;

      const matching = finalSuggestions.find(s => s.category === learned.category);

      if (matching) {
        matching.confidence = Math.min(matching.confidence + learned.confidence * 0.25, 1);
        matching.sources = matching.sources || [];
        if (!matching.sources.includes('learned')) {
          matching.sources.push('learned');
        }
        matching.learnedConfidence = learned.confidence;
      }
    }
  }

  finalSuggestions.sort((a, b) => b.confidence - a.confidence);

  if (finalSuggestions.length > 0) {
    categorySelect.value = finalSuggestions[0].category;
    suggestedCategory = finalSuggestions[0].category;
    categoryConfidence = finalSuggestions[0].confidence;
    if (pillsWrapper) pillsWrapper.style.display = 'block';
  } else {
    suggestedCategory = null;
    categoryConfidence = 0;
    if (pillsWrapper) pillsWrapper.style.display = 'none';
  }

  pillsContainer.innerHTML = '';
  finalSuggestions.slice(0, 3).forEach((suggestion, index) => {
    const pill = document.createElement('button');
    pill.type = 'button';

    const wasBoostedByLearned = suggestion.sources?.includes('learned');
    const isActive = index === 0;
    pill.className = `category-pill ${wasBoostedByLearned ? 'learned' : ''} ${isActive ? 'active' : ''}`;

    pill.textContent = getCategoryLabel(suggestion.category);

    pill.addEventListener('click', () => {
      categorySelect.value = suggestion.category;
      document.querySelectorAll('.category-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
    });

    pillsContainer.appendChild(pill);
  });

  categorySelect.addEventListener('change', () => {
    const currentValue = categorySelect.value;
    document.querySelectorAll('.category-pill').forEach(pill => {
      const pillCategory = finalSuggestions.find(
        s => getCategoryLabel(s.category) === pill.textContent.replace(/\d+%$/, '').trim()
      )?.category;
      pill.classList.toggle('active', pillCategory === currentValue);
    });
  });
}

// ============ Status Messages ============

function showStatus(element, type, message) {
  element.className = `status-message ${type} visible`;
  element.querySelector("span").textContent = message;

  const iconPaths = {
    success: "M5 13l4 4L19 7",
    error: "M6 18L18 6M6 6l12 12",
    loading:
      "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15",
  };

  const svg = element.querySelector("svg path");
  if (svg && iconPaths[type]) {
    svg.setAttribute("d", iconPaths[type]);
  }
}

function hideStatus(element) {
  element.className = "status-message";
}

// ============ Current State ============

let currentCaptureContext = {
  url: "",
  domain: "",
  selectors: {},
  html_samples: {},
  engine: "manual-v1",
};

let scrapedProduct = null;
let currentToken = null;

// ============ Main Initialization ============

document.addEventListener("DOMContentLoaded", async () => {
  // Config screen elements
  const configScreen = document.getElementById("config-screen");
  const tokenInput = document.getElementById("token-input");
  const tokenHelpLink = document.getElementById("token-help-link");
  const connectBtn = document.getElementById("connect-btn");
  const configError = document.getElementById("config-error");

  // Main screen elements
  const mainScreen = document.getElementById("main-screen");
  const settingsBtn = document.getElementById("settings-btn");
  const settingsOverlay = document.getElementById("settings-overlay");
  const settingsTokenDisplay = document.getElementById("settings-token-display");
  const settingsCancel = document.getElementById("settings-cancel");
  const settingsLogout = document.getElementById("settings-logout");

  const projectSelect = document.getElementById("project-select");
  const sectionSelect = document.getElementById("section-select");
  const addItemBtn = document.getElementById("add-item");
  const actionStatus = document.getElementById("action-status");

  const pagePill = document.getElementById("page-pill");
  const namePreview = document.getElementById("name-preview");
  const pricePreview = document.getElementById("price-preview");
  const thumbPreview = document.getElementById("thumb-preview");

  const nameInput = document.getElementById("name-input");
  const noteInput = document.getElementById("note-input");
  const quantityInput = document.getElementById("quantity-input");
  const unitSelect = document.getElementById("unit-select");
  const priceInput = document.getElementById("price-input");
  const statusSelect = document.getElementById("status-select");
  const discountInput = document.getElementById("discount-input");
  const dimensionsInput = document.getElementById("dimensions-input");
  const categorySelect = document.getElementById("category-select");
  const categorySuggestions = document.getElementById("category-suggestions");
  const categorySuggestionsWrapper = document.getElementById("category-suggestions-wrapper");
  const thumbInput = document.getElementById("thumb-input");
  const urlInput = document.getElementById("url-input");
  const pricePickerBtn = document.getElementById("price-picker-btn");

  // ============ Check for Existing Token ============

  currentToken = await getStoredToken();

  if (currentToken) {
    const isValid = await validateToken(currentToken);
    if (isValid) {
      showMainScreen();
      await initMainScreen();
    } else {
      await clearToken();
      currentToken = null;
      showConfigScreen();
    }
  } else {
    showConfigScreen();
  }

  // ============ Config Screen Handlers ============

  tokenHelpLink.addEventListener("click", (e) => {
    e.preventDefault();
    browserApi.tabs.create({ url: `${API_BASE_URL}/workspace` });
  });

  connectBtn.addEventListener("click", async () => {
    const token = tokenInput.value.trim();

    if (!token) {
      configError.textContent = "Wklej token API";
      configError.classList.add("visible");
      return;
    }

    connectBtn.disabled = true;
    connectBtn.textContent = "Łączenie...";
    configError.classList.remove("visible");

    const isValid = await validateToken(token);

    if (isValid) {
      await saveToken(token);
      currentToken = token;
      showMainScreen();
      await initMainScreen();
    } else {
      configError.textContent = "Nieprawidłowy token. Sprawdź i spróbuj ponownie.";
      configError.classList.add("visible");
    }

    connectBtn.disabled = false;
    connectBtn.textContent = "Połącz z SAIVED";
  });

  tokenInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      connectBtn.click();
    }
  });

  // ============ Settings Handlers ============

  settingsBtn.addEventListener("click", () => {
    if (currentToken) {
      const masked =
        currentToken.substring(0, 4) +
        "..." +
        currentToken.substring(currentToken.length - 4);
      settingsTokenDisplay.textContent = masked;
    }
    settingsOverlay.classList.add("active");
  });

  settingsCancel.addEventListener("click", () => {
    settingsOverlay.classList.remove("active");
  });

  settingsOverlay.addEventListener("click", (e) => {
    if (e.target === settingsOverlay) {
      settingsOverlay.classList.remove("active");
    }
  });

  settingsLogout.addEventListener("click", async () => {
    await clearToken();
    currentToken = null;
    settingsOverlay.classList.remove("active");
    tokenInput.value = "";
    showConfigScreen();
  });

  // ============ Collapsible "Więcej opcji" ============

  const extraFieldsTrigger = document.getElementById("extra-fields-trigger");
  const extraFieldsContainer = document.getElementById("extra-fields");

  extraFieldsTrigger.addEventListener("click", () => {
    extraFieldsContainer.classList.toggle("open");
  });

  // ============ Price Picker ============

  async function startPricePicker() {
    const [tab] = await browserApi.tabs.query({ active: true, currentWindow: true });

    // Save form state and tab info
    const formState = {
      name: nameInput.value,
      price: priceInput.value,
      quantity: quantityInput.value,
      unit: unitSelect.value,
      note: noteInput.value,
      status: statusSelect.value,
      discount: discountInput.value,
      dimensions: dimensionsInput.value,
      category: categorySelect.value,
      thumb: thumbInput.value,
      url: urlInput.value,
      projectId: projectSelect.value,
      sectionId: sectionSelect.value
    };

    await browserApi.storage.local.set({
      [PRICE_PICKER_KEY]: {
        status: "picking",
        formState,
        tabId: tab.id,
        timestamp: Date.now()
      }
    });

    // Send message to content script to start picker mode
    browserApi.tabs.sendMessage(tab.id, { type: "SAIVED_START_PRICE_PICKER" });

    // Close popup
    window.close();
  }

  // ============ Main Screen Initialization ============

  async function initMainScreen() {
    // Price picker button handler
    pricePickerBtn.addEventListener("click", startPricePicker);

    // Shortcut hint
    const shortcutHint = document.getElementById("shortcut-hint");
    if (shortcutHint) {
      const isMac = navigator.platform.toUpperCase().indexOf("MAC") >= 0;
      const shortcut = isMac ? "⌥⇧S" : "Alt+Shift+S";
      shortcutHint.innerHTML = `Tip: <kbd>${shortcut}</kbd> otwiera wtyczkę z każdej strony`;
    }

    // Check for price picker result
    const [tab] = await browserApi.tabs.query({ active: true, currentWindow: true });
    const pickerData = await browserApi.storage.local.get(PRICE_PICKER_KEY);
    const picker = pickerData[PRICE_PICKER_KEY];

    // Flag to prevent scraping from overwriting picker price
    let priceFromPicker = false;

    // If we have a completed picker result for this tab, apply it
    if (picker?.status === "completed" && picker.result && picker.tabId === tab?.id) {
      console.log("[SAIVED] Applying price picker result:", picker.result);

      // Restore form state
      if (picker.formState) {
        nameInput.value = picker.formState.name || "";
        priceInput.value = picker.formState.price || "";
        quantityInput.value = picker.formState.quantity || "1";
        unitSelect.value = picker.formState.unit || "szt";
        noteInput.value = picker.formState.note || "";
        statusSelect.value = picker.formState.status || "bez_statusu";
        discountInput.value = picker.formState.discount || "";
        dimensionsInput.value = picker.formState.dimensions || "";
        categorySelect.value = picker.formState.category || "";
        thumbInput.value = picker.formState.thumb || "";
        urlInput.value = picker.formState.url || "";
      }

      // Apply the new price from picker
      if (picker.result.price != null) {
        priceInput.value = picker.result.price;
        pricePreview.textContent = `${picker.result.price.toFixed(2)} zł`;
        priceFromPicker = true;
      }

      // Store discovered selector for learning
      if (picker.result.selector) {
        currentCaptureContext.discovered_selectors = currentCaptureContext.discovered_selectors || {};
        currentCaptureContext.discovered_selectors.price = {
          candidates: [{
            selector: picker.result.selector,
            score: 100
          }]
        };
      }

      // Clear picker data
      await browserApi.storage.local.remove(PRICE_PICKER_KEY);
    } else {
      // Clean up stale picker data (different tab or cancelled)
      await browserApi.storage.local.remove(PRICE_PICKER_KEY);
    }

    // Global Enter key handler
    document.addEventListener("keydown", (e) => {
      if (
        e.key === "Enter" &&
        !e.shiftKey &&
        e.target.tagName !== "TEXTAREA" &&
        mainScreen.classList.contains("active")
      ) {
        e.preventDefault();
        addItemBtn.click();
      }
    });

    // Load projects
    await loadProjects(projectSelect, sectionSelect);

    // Scrape current page
    try {
      if (!tab || !tab.id) {
        pagePill.textContent = "Brak karty";
        pagePill.className = "domain-pill";
      } else {
        pagePill.textContent = "Pobieram...";
        pagePill.className = "domain-pill loading";

        // Extract domain and fetch learned selectors + categories in parallel
        let learnedSelectors = {};
        let learnedCategories = null;
        let currentDomain = "";
        try {
          const tabUrl = new URL(tab.url);
          currentDomain = tabUrl.hostname;
          const [selectors, categories] = await Promise.all([
            fetchLearnedSelectors(currentDomain, currentToken),
            fetchLearnedCategories(currentDomain, currentToken)
          ]);
          learnedSelectors = selectors;
          learnedCategories = categories;
        } catch (e) {
          console.warn("[SAIVED] Could not extract domain:", e);
        }

        browserApi.tabs.sendMessage(
          tab.id,
          { type: "SAIVED_SCRAPE_PAGE", learnedSelectors },
          (response) => {
            if (browserApi.runtime.lastError) {
              console.warn("[SAIVED] runtime error:", browserApi.runtime.lastError);
              pagePill.textContent = "Brak danych";
              pagePill.className = "domain-pill";
              urlInput.value = tab.url || "";
              return;
            }

            if (!response || !response.ok) {
              pagePill.textContent = "Brak danych";
              pagePill.className = "domain-pill";
              urlInput.value = tab.url || "";
              return;
            }

            const { product, capture_context } = response.data || {};
            scrapedProduct = product || null;
            currentCaptureContext = capture_context || currentCaptureContext;

            // Update domain pill
            pagePill.textContent = capture_context.domain || "Strona";
            pagePill.className = "domain-pill ready";

            // Update preview + form (but respect priceFromPicker flag)
            if (product.name) {
              namePreview.textContent = product.name;
              if (!priceFromPicker) {
                nameInput.value = product.name;
              }
            } else {
              namePreview.textContent = "Nie znaleziono nazwy";
            }

            if (product.external_url) {
              if (!priceFromPicker) {
                urlInput.value = product.external_url;
              }
            } else if (tab.url && !priceFromPicker) {
              urlInput.value = tab.url;
            }

            // Only update price if not from picker
            if (!priceFromPicker) {
              if (product.unit_price != null) {
                pricePreview.textContent = `${product.unit_price.toFixed(2)} zł`;
                priceInput.value = product.unit_price;
              } else {
                pricePreview.textContent = "—";
              }
            }

            if (product.thumbnail_url) {
              if (!priceFromPicker) {
                thumbInput.value = product.thumbnail_url;
              }
              thumbPreview.innerHTML = `<img src="${product.thumbnail_url}" alt="">`;
            } else {
              thumbPreview.innerHTML = `
                <div class="product-thumb-placeholder">
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
              `;
            }

            // Display category suggestions
            const heuristicSuggestions = capture_context.category_suggestions || [];
            displayCategorySuggestions(
              heuristicSuggestions,
              learnedCategories,
              categorySelect,
              categorySuggestions,
              categorySuggestionsWrapper
            );
          }
        );
      }
    } catch (e) {
      console.error("[SAIVED] Error querying tabs:", e);
    }

    // Project change handler
    projectSelect.addEventListener("change", async () => {
      const projectId = projectSelect.value || null;
      await browserApi.storage.local.set({ lastProjectId: projectId });

      if (projectId) {
        await populateSectionsForSelectedProject(projectSelect, sectionSelect);
      } else {
        sectionSelect.innerHTML = '<option value="">(wybierz projekt)</option>';
      }
    });

    // Section change handler
    sectionSelect.addEventListener("change", async () => {
      const sectionId = sectionSelect.value || null;
      await browserApi.storage.local.set({ lastSectionId: sectionId });
    });

    // Add item handler
    addItemBtn.addEventListener("click", async () => {
      hideStatus(actionStatus);

      const projectId = projectSelect.value;
      const sectionId = sectionSelect.value;

      if (!projectId) {
        showStatus(actionStatus, "error", "Wybierz projekt");
        return;
      }
      if (!sectionId) {
        showStatus(actionStatus, "error", "Wybierz sekcję");
        return;
      }

      const name = nameInput.value.trim();
      if (!name) {
        showStatus(actionStatus, "error", "Podaj nazwę produktu");
        return;
      }

      const qty = parseInt(quantityInput.value || "1", 10) || 1;
      const priceVal = parseFloat(priceInput.value.replace(",", "."));
      const unitPrice = Number.isNaN(priceVal) ? null : priceVal;

      // Build corrected data object
      const correctedData = {
        name,
        unit_price: unitPrice,
        thumbnail_url: thumbInput.value.trim() || null,
      };

      // Original scraped data
      const originalData = scrapedProduct || {};

      // Check if user made corrections - if so, discover better selectors
      let discoveredSelectors = null;
      const hasCorrections =
        (correctedData.name && correctedData.name !== originalData.name) ||
        (correctedData.unit_price != null &&
          correctedData.unit_price !== originalData.unit_price) ||
        (correctedData.thumbnail_url &&
          correctedData.thumbnail_url !== originalData.thumbnail_url);

      if (hasCorrections) {
        showStatus(actionStatus, "loading", "Uczę się...");
        console.log("[SAIVED] User made corrections, discovering selectors...");

        try {
          const [currentTab] = await browserApi.tabs.query({
            active: true,
            currentWindow: true,
          });
          if (currentTab && currentTab.id) {
            const response = await new Promise((resolve) => {
              browserApi.tabs.sendMessage(
                currentTab.id,
                {
                  type: "SAIVED_DISCOVER_SELECTORS",
                  originalData,
                  correctedData,
                },
                resolve
              );
            });

            if (response && response.ok && response.discoveries) {
              discoveredSelectors = response.discoveries;
              console.log("[SAIVED] Discovered selectors:", discoveredSelectors);
            }
          }
        } catch (e) {
          console.warn("[SAIVED] Discovery failed:", e);
        }
      }

      // Build capture context with discovered selectors
      const captureContext = currentCaptureContext || {
        url: urlInput.value.trim() || "",
        domain: "",
        selectors: {},
        html_samples: {},
        engine: "manual-v1",
      };

      // Add discovered selectors to context
      if (discoveredSelectors) {
        captureContext.discovered_selectors = discoveredSelectors;
      }

      // Add suggested category for learning
      if (suggestedCategory) {
        captureContext.suggested_category = suggestedCategory;
        captureContext.category_confidence = categoryConfidence;
      }

      const payload = {
        product_item: {
          name,
          note: noteInput.value.trim() || null,
          quantity: qty,
          unit_type: unitSelect.value || "szt",
          unit_price: unitPrice,
          currency: "PLN",
          category: categorySelect.value || null,
          dimensions: dimensionsInput.value.trim() || null,
          status: statusSelect.value || "bez_statusu",
          external_url: urlInput.value.trim() || null,
          discount_label: discountInput.value.trim() || null,
          thumbnail_url: thumbInput.value.trim() || null,
        },
        capture_context: captureContext,
        original_product: scrapedProduct,
      };

      try {
        showStatus(actionStatus, "loading", "Dodaję...");

        const res = await fetch(
          `${API_BASE_URL}/api/v1/project_sections/${sectionId}/items`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${currentToken}`,
            },
            body: JSON.stringify(payload),
          }
        );

        if (!res.ok) {
          const text = await res.text();
          showStatus(actionStatus, "error", `Błąd API: ${res.status}`);
          console.error("[SAIVED] API error:", text);
          return;
        }

        const data = await res.json();
        console.log("[SAIVED] Added item:", data);
        showStatus(actionStatus, "success", "Dodano!");

        // Auto-close popup after brief delay
        setTimeout(() => window.close(), 800);
      } catch (e) {
        console.error(e);
        showStatus(actionStatus, "error", "Błąd połączenia");
      }
    });
  }

  // ============ Projects & Sections ============

  async function loadProjects(projectSelect, sectionSelect, opts = {}) {
    const stored = await browserApi.storage.local.get([
      "lastProjectId",
      "lastSectionId",
    ]);

    projectSelect.innerHTML = '<option value="">Ładowanie...</option>';
    sectionSelect.innerHTML = '<option value="">(wybierz projekt)</option>';

    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/projects`, {
        headers: {
          Authorization: `Bearer ${currentToken}`,
        },
      });

      if (!res.ok) {
        projectSelect.innerHTML = '<option value="">Błąd pobierania</option>';
        return;
      }

      const data = await res.json();
      const projects = data.projects || [];

      if (projects.length === 0) {
        projectSelect.innerHTML = '<option value="">Brak projektów</option>';
        return;
      }

      projectSelect.innerHTML = "";
      projects.forEach((project) => {
        const opt = document.createElement("option");
        opt.value = String(project.id);
        opt.textContent = project.name || `Projekt #${project.id}`;
        projectSelect.appendChild(opt);
      });

      // Restore last project OR auto-select first one
      let selectedProjectId = null;

      if (stored.lastProjectId) {
        const found = Array.from(projectSelect.options).find(
          (o) => o.value === String(stored.lastProjectId)
        );
        if (found) {
          projectSelect.value = String(stored.lastProjectId);
          selectedProjectId = stored.lastProjectId;
        }
      }

      // If no stored project (or it was deleted), auto-select first project
      if (!selectedProjectId && projects.length > 0) {
        projectSelect.value = String(projects[0].id);
        selectedProjectId = projects[0].id;
        await browserApi.storage.local.set({ lastProjectId: String(projects[0].id) });
      }

      // Always load sections for selected project
      if (selectedProjectId) {
        await populateSectionsForSelectedProject(
          projectSelect,
          sectionSelect,
          stored
        );
      }
    } catch (e) {
      console.error(e);
      projectSelect.innerHTML = '<option value="">Błąd sieci</option>';
    }
  }

  async function populateSectionsForSelectedProject(
    projectSelect,
    sectionSelect,
    stored = {}
  ) {
    const projectId = projectSelect.value;
    if (!projectId) {
      sectionSelect.innerHTML = '<option value="">(wybierz projekt)</option>';
      return;
    }

    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/projects/${projectId}`, {
        headers: {
          Authorization: `Bearer ${currentToken}`,
        },
      });

      if (!res.ok) {
        sectionSelect.innerHTML = '<option value="">Błąd pobierania</option>';
        return;
      }

      const data = await res.json();
      const sections = data.sections || [];

      if (sections.length === 0) {
        sectionSelect.innerHTML = '<option value="">Brak sekcji</option>';
        return;
      }

      sectionSelect.innerHTML = "";
      sections.forEach((section) => {
        const opt = document.createElement("option");
        opt.value = String(section.id);
        opt.textContent = section.name || `Sekcja #${section.id}`;
        sectionSelect.appendChild(opt);
      });

      // Restore last section OR auto-select first one
      let selectedSectionId = null;

      if (stored.lastSectionId) {
        const found = Array.from(sectionSelect.options).find(
          (o) => o.value === String(stored.lastSectionId)
        );
        if (found) {
          sectionSelect.value = String(stored.lastSectionId);
          selectedSectionId = stored.lastSectionId;
        }
      }

      // If no stored section (or it was deleted), auto-select first section
      if (!selectedSectionId && sections.length > 0) {
        sectionSelect.value = String(sections[0].id);
        await browserApi.storage.local.set({ lastSectionId: String(sections[0].id) });
      }
    } catch (e) {
      console.error(e);
      sectionSelect.innerHTML = '<option value="">Błąd sieci</option>';
    }
  }
});
