const API_BASE_URL = "https://saived.ai";
const browserApi = typeof browser !== "undefined" ? browser : chrome;

// ============ Token Management ============

async function getStoredToken() {
  const { apiToken } = await browserApi.storage.local.get(["apiToken"]);
  return apiToken || null;
}

async function saveToken(token) {
  await browserApi.storage.local.set({ apiToken: token });
}

async function clearToken() {
  await browserApi.storage.local.remove(["apiToken"]);
}

async function validateToken(token) {
  if (!token) return false;

  try {
    const res = await fetch(`${API_BASE_URL}/api/v1/projects`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return res.ok;
  } catch (e) {
    console.warn("[SAIVED] Token validation error:", e);
    return false;
  }
}

// ============ Screen Management ============

function showConfigScreen() {
  document.getElementById("config-screen").classList.add("active");
  document.getElementById("main-screen").classList.remove("active");
}

function showMainScreen() {
  document.getElementById("config-screen").classList.remove("active");
  document.getElementById("main-screen").classList.add("active");
}

// ============ Learned Selectors ============

async function fetchLearnedSelectors(domain, token) {
  if (!domain || !token) return {};

  try {
    const res = await fetch(
      `${API_BASE_URL}/api/v1/selectors?domain=${encodeURIComponent(domain)}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (!res.ok) {
      console.warn("[SAIVED] Failed to fetch learned selectors:", res.status);
      return {};
    }

    const data = await res.json();
    console.log("[SAIVED] Learned selectors for", domain, ":", data);
    return data.selectors || {};
  } catch (e) {
    console.warn("[SAIVED] Error fetching learned selectors:", e);
    return {};
  }
}

// ============ Status Messages ============

function showStatus(element, type, message) {
  element.className = `status-message ${type} visible`;
  element.querySelector("span").textContent = message;

  const iconPaths = {
    success: "M5 13l4 4L19 7",
    error: "M6 18L18 6M6 6l12 12",
    loading:
      "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15",
  };

  const svg = element.querySelector("svg path");
  if (svg && iconPaths[type]) {
    svg.setAttribute("d", iconPaths[type]);
  }
}

function hideStatus(element) {
  element.className = "status-message";
}

// ============ Current State ============

let currentCaptureContext = {
  url: "",
  domain: "",
  selectors: {},
  html_samples: {},
  engine: "manual-v1",
};

let scrapedProduct = null;
let currentToken = null;

// ============ Main Initialization ============

document.addEventListener("DOMContentLoaded", async () => {
  // Config screen elements
  const configScreen = document.getElementById("config-screen");
  const tokenInput = document.getElementById("token-input");
  const tokenHelpLink = document.getElementById("token-help-link");
  const connectBtn = document.getElementById("connect-btn");
  const configError = document.getElementById("config-error");

  // Main screen elements
  const mainScreen = document.getElementById("main-screen");
  const settingsBtn = document.getElementById("settings-btn");
  const settingsOverlay = document.getElementById("settings-overlay");
  const settingsTokenDisplay = document.getElementById("settings-token-display");
  const settingsCancel = document.getElementById("settings-cancel");
  const settingsLogout = document.getElementById("settings-logout");

  const projectSelect = document.getElementById("project-select");
  const sectionSelect = document.getElementById("section-select");
  const addItemBtn = document.getElementById("add-item");
  const actionStatus = document.getElementById("action-status");

  const pagePill = document.getElementById("page-pill");
  const namePreview = document.getElementById("name-preview");
  const pricePreview = document.getElementById("price-preview");
  const thumbPreview = document.getElementById("thumb-preview");

  const nameInput = document.getElementById("name-input");
  const noteInput = document.getElementById("note-input");
  const quantityInput = document.getElementById("quantity-input");
  const priceInput = document.getElementById("price-input");
  const statusSelect = document.getElementById("status-select");
  const discountInput = document.getElementById("discount-input");
  const dimensionsInput = document.getElementById("dimensions-input");
  const categoryInput = document.getElementById("category-input");
  const thumbInput = document.getElementById("thumb-input");
  const urlInput = document.getElementById("url-input");

  // ============ Check for Existing Token ============

  currentToken = await getStoredToken();

  if (currentToken) {
    // Validate token
    const isValid = await validateToken(currentToken);
    if (isValid) {
      showMainScreen();
      await initMainScreen();
    } else {
      // Token is invalid, clear it and show config
      await clearToken();
      currentToken = null;
      showConfigScreen();
    }
  } else {
    showConfigScreen();
  }

  // ============ Config Screen Handlers ============

  tokenHelpLink.addEventListener("click", (e) => {
    e.preventDefault();
    browserApi.tabs.create({ url: `${API_BASE_URL}/workspace` });
  });

  connectBtn.addEventListener("click", async () => {
    const token = tokenInput.value.trim();

    if (!token) {
      configError.textContent = "Wklej token API";
      configError.classList.add("visible");
      return;
    }

    connectBtn.disabled = true;
    connectBtn.textContent = "Laczenie...";
    configError.classList.remove("visible");

    const isValid = await validateToken(token);

    if (isValid) {
      await saveToken(token);
      currentToken = token;
      showMainScreen();
      await initMainScreen();
    } else {
      configError.textContent = "Nieprawidlowy token. Sprawdz i sprobuj ponownie.";
      configError.classList.add("visible");
    }

    connectBtn.disabled = false;
    connectBtn.textContent = "Polacz z SAIVED";
  });

  // Enter key in token input
  tokenInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      connectBtn.click();
    }
  });

  // ============ Settings Handlers ============

  settingsBtn.addEventListener("click", () => {
    // Mask token for display
    if (currentToken) {
      const masked =
        currentToken.substring(0, 4) +
        "..." +
        currentToken.substring(currentToken.length - 4);
      settingsTokenDisplay.textContent = masked;
    }
    settingsOverlay.classList.add("active");
  });

  settingsCancel.addEventListener("click", () => {
    settingsOverlay.classList.remove("active");
  });

  settingsOverlay.addEventListener("click", (e) => {
    if (e.target === settingsOverlay) {
      settingsOverlay.classList.remove("active");
    }
  });

  settingsLogout.addEventListener("click", async () => {
    await clearToken();
    currentToken = null;
    settingsOverlay.classList.remove("active");
    tokenInput.value = "";
    showConfigScreen();
  });

  // ============ Collapsible "Więcej opcji" ============

  const extraFieldsTrigger = document.getElementById("extra-fields-trigger");
  const extraFieldsContainer = document.getElementById("extra-fields");

  extraFieldsTrigger.addEventListener("click", () => {
    extraFieldsContainer.classList.toggle("open");
  });

  // ============ Main Screen Initialization ============

  async function initMainScreen() {
    // Global Enter key handler - submit form quickly
    document.addEventListener("keydown", (e) => {
      if (
        e.key === "Enter" &&
        !e.shiftKey &&
        e.target.tagName !== "TEXTAREA" &&
        mainScreen.classList.contains("active")
      ) {
        e.preventDefault();
        addItemBtn.click();
      }
    });

    // Load projects
    await loadProjects(projectSelect, sectionSelect);

    // Scrape current page
    try {
      const [tab] = await browserApi.tabs.query({
        active: true,
        currentWindow: true,
      });

      if (!tab || !tab.id) {
        pagePill.textContent = "Brak karty";
        pagePill.className = "domain-pill";
      } else {
        pagePill.textContent = "Pobieram...";
        pagePill.className = "domain-pill loading";

        // Extract domain and fetch learned selectors
        let learnedSelectors = {};
        try {
          const tabUrl = new URL(tab.url);
          const domain = tabUrl.hostname;
          learnedSelectors = await fetchLearnedSelectors(domain, currentToken);
        } catch (e) {
          console.warn("[SAIVED] Could not extract domain:", e);
        }

        browserApi.tabs.sendMessage(
          tab.id,
          { type: "SAIVED_SCRAPE_PAGE", learnedSelectors },
          (response) => {
            if (browserApi.runtime.lastError) {
              console.warn(
                "[SAIVED] runtime error:",
                browserApi.runtime.lastError
              );
              pagePill.textContent = "Brak danych";
              pagePill.className = "domain-pill";
              urlInput.value = tab.url || "";
              return;
            }

            if (!response || !response.ok) {
              pagePill.textContent = "Brak danych";
              pagePill.className = "domain-pill";
              urlInput.value = tab.url || "";
              return;
            }

            const { product, capture_context } = response.data || {};
            scrapedProduct = product || null;
            currentCaptureContext = capture_context || currentCaptureContext;

            // Update domain pill
            pagePill.textContent = capture_context.domain || "Strona";
            pagePill.className = "domain-pill ready";

            // Update preview + form
            if (product.name) {
              namePreview.textContent = product.name;
              nameInput.value = product.name;
            } else {
              namePreview.textContent = "Nie znaleziono nazwy";
            }

            if (product.external_url) {
              urlInput.value = product.external_url;
            } else if (tab.url) {
              urlInput.value = tab.url;
            }

            if (product.unit_price != null) {
              pricePreview.textContent = `${product.unit_price.toFixed(2)} zl`;
              priceInput.value = product.unit_price;
            } else {
              pricePreview.textContent = "—";
            }

            if (product.thumbnail_url) {
              thumbInput.value = product.thumbnail_url;
              thumbPreview.innerHTML = `<img src="${product.thumbnail_url}" alt="">`;
            } else {
              thumbPreview.innerHTML = `
                <div class="product-thumb-placeholder">
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
              `;
            }
          }
        );
      }
    } catch (e) {
      console.error("[SAIVED] Error querying tabs:", e);
    }

    // Project change handler
    projectSelect.addEventListener("change", async () => {
      const projectId = projectSelect.value || null;
      await browserApi.storage.local.set({ lastProjectId: projectId });

      if (projectId) {
        await populateSectionsForSelectedProject(projectSelect, sectionSelect);
      } else {
        sectionSelect.innerHTML = '<option value="">(wybierz projekt)</option>';
      }
    });

    // Section change handler
    sectionSelect.addEventListener("change", async () => {
      const sectionId = sectionSelect.value || null;
      await browserApi.storage.local.set({ lastSectionId: sectionId });
    });

    // Add item handler
    addItemBtn.addEventListener("click", async () => {
      hideStatus(actionStatus);

      const projectId = projectSelect.value;
      const sectionId = sectionSelect.value;

      if (!projectId) {
        showStatus(actionStatus, "error", "Wybierz projekt");
        return;
      }
      if (!sectionId) {
        showStatus(actionStatus, "error", "Wybierz sekcje");
        return;
      }

      const name = nameInput.value.trim();
      if (!name) {
        showStatus(actionStatus, "error", "Podaj nazwe produktu");
        return;
      }

      const qty = parseInt(quantityInput.value || "1", 10) || 1;
      const priceVal = parseFloat(priceInput.value.replace(",", "."));
      const unitPrice = Number.isNaN(priceVal) ? null : priceVal;

      // Build corrected data object
      const correctedData = {
        name,
        unit_price: unitPrice,
        thumbnail_url: thumbInput.value.trim() || null,
      };

      // Original scraped data
      const originalData = scrapedProduct || {};

      // Check if user made corrections - if so, discover better selectors
      let discoveredSelectors = null;
      const hasCorrections =
        (correctedData.name && correctedData.name !== originalData.name) ||
        (correctedData.unit_price != null &&
          correctedData.unit_price !== originalData.unit_price) ||
        (correctedData.thumbnail_url &&
          correctedData.thumbnail_url !== originalData.thumbnail_url);

      if (hasCorrections) {
        showStatus(actionStatus, "loading", "Ucze sie...");
        console.log("[SAIVED] User made corrections, discovering selectors...");

        try {
          const [tab] = await browserApi.tabs.query({
            active: true,
            currentWindow: true,
          });
          if (tab && tab.id) {
            const response = await new Promise((resolve) => {
              browserApi.tabs.sendMessage(
                tab.id,
                {
                  type: "SAIVED_DISCOVER_SELECTORS",
                  originalData,
                  correctedData,
                },
                resolve
              );
            });

            if (response && response.ok && response.discoveries) {
              discoveredSelectors = response.discoveries;
              console.log("[SAIVED] Discovered selectors:", discoveredSelectors);
            }
          }
        } catch (e) {
          console.warn("[SAIVED] Discovery failed:", e);
        }
      }

      // Build capture context with discovered selectors
      const captureContext = currentCaptureContext || {
        url: urlInput.value.trim() || "",
        domain: "",
        selectors: {},
        html_samples: {},
        engine: "manual-v1",
      };

      // Add discovered selectors to context
      if (discoveredSelectors) {
        captureContext.discovered_selectors = discoveredSelectors;
      }

      const payload = {
        product_item: {
          name,
          note: noteInput.value.trim() || null,
          quantity: qty,
          unit_price: unitPrice,
          currency: "PLN",
          category: categoryInput.value.trim() || null,
          dimensions: dimensionsInput.value.trim() || null,
          status: statusSelect.value || "propozycja",
          external_url: urlInput.value.trim() || null,
          discount_label: discountInput.value.trim() || null,
          thumbnail_url: thumbInput.value.trim() || null,
        },
        capture_context: captureContext,
        original_product: scrapedProduct,
      };

      try {
        showStatus(actionStatus, "loading", "Dodaje...");

        const res = await fetch(
          `${API_BASE_URL}/api/v1/project_sections/${sectionId}/items`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${currentToken}`,
            },
            body: JSON.stringify(payload),
          }
        );

        if (!res.ok) {
          const text = await res.text();
          showStatus(actionStatus, "error", `Blad API: ${res.status}`);
          console.error("[SAIVED] API error:", text);
          return;
        }

        const data = await res.json();
        console.log("[SAIVED] Added item:", data);
        showStatus(actionStatus, "success", "Dodano!");

        // Auto-close popup after brief delay
        setTimeout(() => window.close(), 800);
      } catch (e) {
        console.error(e);
        showStatus(actionStatus, "error", "Blad polaczenia");
      }
    });
  }

  // ============ Projects & Sections ============

  async function loadProjects(projectSelect, sectionSelect, opts = {}) {
    const stored = await browserApi.storage.local.get([
      "lastProjectId",
      "lastSectionId",
    ]);

    projectSelect.innerHTML = '<option value="">Ladowanie...</option>';
    sectionSelect.innerHTML = '<option value="">(wybierz projekt)</option>';

    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/projects`, {
        headers: {
          Authorization: `Bearer ${currentToken}`,
        },
      });

      if (!res.ok) {
        projectSelect.innerHTML = '<option value="">Blad pobierania</option>';
        return;
      }

      const data = await res.json();
      const projects = data.projects || [];

      if (projects.length === 0) {
        projectSelect.innerHTML = '<option value="">Brak projektow</option>';
        return;
      }

      projectSelect.innerHTML = "";
      projects.forEach((project) => {
        const opt = document.createElement("option");
        opt.value = String(project.id);
        opt.textContent = project.name || `Projekt #${project.id}`;
        projectSelect.appendChild(opt);
      });

      // Restore last project OR auto-select first one
      let selectedProjectId = null;

      if (stored.lastProjectId) {
        const found = Array.from(projectSelect.options).find(
          (o) => o.value === String(stored.lastProjectId)
        );
        if (found) {
          projectSelect.value = String(stored.lastProjectId);
          selectedProjectId = stored.lastProjectId;
        }
      }

      // If no stored project (or it was deleted), auto-select first project
      if (!selectedProjectId && projects.length > 0) {
        projectSelect.value = String(projects[0].id);
        selectedProjectId = projects[0].id;
        // Save as last project so it persists
        await browserApi.storage.local.set({ lastProjectId: String(projects[0].id) });
      }

      // Always load sections for selected project
      if (selectedProjectId) {
        await populateSectionsForSelectedProject(
          projectSelect,
          sectionSelect,
          stored
        );
      }
    } catch (e) {
      console.error(e);
      projectSelect.innerHTML = '<option value="">Blad sieci</option>';
    }
  }

  async function populateSectionsForSelectedProject(
    projectSelect,
    sectionSelect,
    stored = {}
  ) {
    const projectId = projectSelect.value;
    if (!projectId) {
      sectionSelect.innerHTML = '<option value="">(wybierz projekt)</option>';
      return;
    }

    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/projects/${projectId}`, {
        headers: {
          Authorization: `Bearer ${currentToken}`,
        },
      });

      if (!res.ok) {
        sectionSelect.innerHTML = '<option value="">Blad pobierania</option>';
        return;
      }

      const data = await res.json();
      const sections = data.sections || [];

      if (sections.length === 0) {
        sectionSelect.innerHTML = '<option value="">Brak sekcji</option>';
        return;
      }

      sectionSelect.innerHTML = "";
      sections.forEach((section) => {
        const opt = document.createElement("option");
        opt.value = String(section.id);
        opt.textContent = section.name || `Sekcja #${section.id}`;
        sectionSelect.appendChild(opt);
      });

      // Restore last section OR auto-select first one
      let selectedSectionId = null;

      if (stored.lastSectionId) {
        const found = Array.from(sectionSelect.options).find(
          (o) => o.value === String(stored.lastSectionId)
        );
        if (found) {
          sectionSelect.value = String(stored.lastSectionId);
          selectedSectionId = stored.lastSectionId;
        }
      }

      // If no stored section (or it was deleted), auto-select first section
      if (!selectedSectionId && sections.length > 0) {
        sectionSelect.value = String(sections[0].id);
        // Save as last section so it persists
        await browserApi.storage.local.set({ lastSectionId: String(sections[0].id) });
      }
    } catch (e) {
      console.error(e);
      sectionSelect.innerHTML = '<option value="">Blad sieci</option>';
    }
  }
});
