// content-script.js
const browserApi = typeof browser !== "undefined" ? browser : chrome;

// Learned selectors from the backend (passed via message)
let learnedSelectors = {};

function safeQuery(selector) {
  try {
    return document.querySelector(selector) || null;
  } catch (e) {
    return null;
  }
}

// ============================================================
// INTERNATIONAL PRICE PARSER
// ============================================================

/**
 * Intelligent price parser that handles international formats:
 * - "329,99" → 329.99 (Polish/European - comma as decimal)
 * - "329.99" → 329.99 (US/UK - dot as decimal)
 * - "4,790.00" → 4790.00 (US with thousands separator)
 * - "4 790,00" → 4790.00 (European with space thousands)
 * - "4.790,00" → 4790.00 (German with dot thousands)
 * - "1 234 567,89" → 1234567.89 (European large numbers)
 */
function parsePrice(text) {
  if (!text) return null;

  // Remove currency symbols, whitespace around edges, and common noise
  let cleaned = text
    .replace(/[zł$€£¥₽PLN\s]+$/gi, '') // Remove trailing currency
    .replace(/^[zł$€£¥₽PLN\s]+/gi, '') // Remove leading currency
    .trim();

  // Extract just the number part (digits, dots, commas, spaces)
  const numberMatch = cleaned.match(/[\d\s.,]+/);
  if (!numberMatch) return null;

  let numStr = numberMatch[0].trim();

  // Remove all spaces (thousand separators in some formats)
  numStr = numStr.replace(/\s/g, '');

  // Now we have something like: "4,790.00" or "4.790,00" or "329,99" or "329.99"

  // Count dots and commas
  const dots = (numStr.match(/\./g) || []).length;
  const commas = (numStr.match(/,/g) || []).length;

  // Determine the decimal separator
  let decimalSep = null;
  let thousandsSep = null;

  if (dots === 0 && commas === 0) {
    // Just digits, no decimals
    const parsed = parseInt(numStr, 10);
    return isNaN(parsed) ? null : parsed;
  }

  if (dots === 1 && commas === 0) {
    // Only dot: check if it's decimal or thousands
    const afterDot = numStr.split('.')[1];
    if (afterDot.length === 2) {
      decimalSep = '.'; // "329.99" → decimal
    } else if (afterDot.length === 3) {
      thousandsSep = '.'; // "4.790" → thousands
    } else {
      decimalSep = '.'; // Default to decimal
    }
  } else if (commas === 1 && dots === 0) {
    // Only comma: check if it's decimal or thousands
    const afterComma = numStr.split(',')[1];
    if (afterComma.length === 2) {
      decimalSep = ','; // "329,99" → decimal
    } else if (afterComma.length === 3) {
      thousandsSep = ','; // "4,790" → thousands
    } else {
      decimalSep = ','; // Default to decimal
    }
  } else if (dots >= 1 && commas >= 1) {
    // Both present: last separator is decimal
    const lastDotPos = numStr.lastIndexOf('.');
    const lastCommaPos = numStr.lastIndexOf(',');

    if (lastDotPos > lastCommaPos) {
      // "4,790.00" → dot is decimal, comma is thousands
      decimalSep = '.';
      thousandsSep = ',';
    } else {
      // "4.790,00" → comma is decimal, dot is thousands
      decimalSep = ',';
      thousandsSep = '.';
    }
  } else if (dots > 1) {
    // Multiple dots: "1.234.567" → dots are thousands, no decimal
    thousandsSep = '.';
  } else if (commas > 1) {
    // Multiple commas: "1,234,567" → commas are thousands, no decimal
    thousandsSep = ',';
  }

  // Build the normalized number string
  if (thousandsSep) {
    numStr = numStr.split(thousandsSep).join('');
  }
  if (decimalSep === ',') {
    numStr = numStr.replace(',', '.');
  }

  const parsed = parseFloat(numStr);
  return isNaN(parsed) ? null : parsed;
}

// ============================================================
// SMART SELECTOR DISCOVERY
// When user corrects a value, search DOM to find the right element
// ============================================================

/**
 * Build a robust, reusable CSS selector for an element
 * Prefers: ID > unique class combinations > structural path
 */
function buildRobustSelector(el) {
  if (!el || !el.tagName) return "";

  // Strategy 1: If element has ID, use it
  if (el.id) {
    return `#${el.id}`;
  }

  // Strategy 2: Try to find a unique class combination
  if (el.className && typeof el.className === 'string') {
    const classes = el.className.split(/\s+/).filter(c => {
      // Filter out dynamic/hash classes
      return c &&
             !c.match(/^[a-f0-9]{6,}$/i) && // hex hashes
             !c.match(/^\d+$/) &&            // pure numbers
             !c.match(/^_/) &&               // underscore prefix (often generated)
             c.length < 30;                  // not too long
    });

    if (classes.length > 0) {
      // Try progressively more specific class combinations
      for (let i = 1; i <= Math.min(classes.length, 3); i++) {
        const selector = el.tagName.toLowerCase() + '.' + classes.slice(0, i).join('.');
        const matches = document.querySelectorAll(selector);
        if (matches.length === 1) {
          return selector;
        }
      }
    }
  }

  // Strategy 3: Build path from nearest ID or unique parent
  let path = [];
  let node = el;
  let foundAnchor = false;

  while (node && node.nodeType === 1 && path.length < 6) {
    let part = node.tagName.toLowerCase();

    if (node.id) {
      part = `#${node.id}`;
      path.unshift(part);
      foundAnchor = true;
      break;
    }

    // Add meaningful classes
    if (node.className && typeof node.className === 'string') {
      const goodClasses = node.className.split(/\s+/).filter(c => {
        return c &&
               c.length < 25 &&
               !c.match(/^[a-f0-9]{6,}$/i) &&
               (c.includes('price') || c.includes('product') || c.includes('title') ||
                c.includes('name') || c.includes('detail') || c.includes('main') ||
                c.includes('info') || c.includes('content') || c.includes('box'));
      }).slice(0, 2);

      if (goodClasses.length > 0) {
        part += '.' + goodClasses.join('.');
      }
    }

    path.unshift(part);
    node = node.parentElement;
  }

  const selector = path.join(' > ');

  // Verify selector works and is reasonably unique
  try {
    const matches = document.querySelectorAll(selector);
    if (matches.length <= 3) {
      return selector;
    }
  } catch (e) {}

  // Fallback to original simple selector
  return buildCssSelector(el);
}

/**
 * Score how likely an element is to be the MAIN PRODUCT PRICE (not promo, not old price)
 */
function scorePriceElement(el) {
  let score = 50; // Base score

  const className = (el.className || '').toLowerCase();
  const id = (el.id || '').toLowerCase();
  const text = (el.innerText || '').toLowerCase();

  // === POSITIVE SIGNALS ===

  // Good class names
  if (className.includes('price') && className.includes('product')) score += 35;
  if (className.includes('price') && className.includes('main')) score += 30;
  if (className.includes('price') && className.includes('current')) score += 30;
  if (className.includes('price') && className.includes('final')) score += 25;
  if (className.includes('price') && className.includes('sale')) score += 20;
  if (className.includes('product-price')) score += 25;
  if (className.includes('actual-price')) score += 25;
  if (id.includes('price')) score += 20;

  // Schema.org markup (very reliable)
  if (el.getAttribute('itemprop') === 'price') score += 50;
  if (el.hasAttribute('data-price')) score += 30;
  if (el.hasAttribute('data-product-price')) score += 35;

  // Check parent chain for product context
  let parent = el.parentElement;
  let depth = 0;
  while (parent && depth < 6) {
    const parentClass = (parent.className || '').toLowerCase();
    const parentId = (parent.id || '').toLowerCase();

    if (parentClass.includes('product-detail') || parentClass.includes('product-info') ||
        parentClass.includes('product-main') || parentClass.includes('pdp-')) {
      score += 30;
      break;
    }
    if (parentId.includes('product')) score += 20;

    // Penalty for being inside promotional/teaser areas
    if (parentClass.includes('teaser') || parentClass.includes('promo') ||
        parentClass.includes('carousel') || parentClass.includes('slider') ||
        parentClass.includes('recommendation') || parentClass.includes('related')) {
      score -= 60;
      break;
    }

    parent = parent.parentElement;
    depth++;
  }

  // Visual prominence
  try {
    const style = window.getComputedStyle(el);
    const fontSize = parseFloat(style.fontSize);
    if (fontSize >= 24) score += 20;
    else if (fontSize >= 18) score += 10;

    // Good colors (dark text usually = main price)
    const color = style.color;
    if (color.includes('0, 0, 0') || color.includes('17, 24, 39')) score += 5;
  } catch (e) {}

  // Position on page (main product price usually in upper portion)
  try {
    const rect = el.getBoundingClientRect();
    if (rect.top > 100 && rect.top < 700) score += 15;
    if (rect.left > 200) score += 5; // Usually not in left sidebar
  } catch (e) {}

  // === NEGATIVE SIGNALS ===

  // Old/crossed-out price
  if (className.includes('old') || className.includes('was') ||
      className.includes('regular') || className.includes('original') ||
      className.includes('before') || className.includes('crossed') ||
      className.includes('line-through')) {
    score -= 80;
  }

  // Check for strikethrough style
  try {
    const style = window.getComputedStyle(el);
    if (style.textDecoration.includes('line-through')) score -= 100;
  } catch (e) {}

  // Promotional/teaser elements
  if (className.includes('teaser') || className.includes('promo') ||
      className.includes('banner') || className.includes('widget') ||
      className.includes('spot') || className.includes('ad-')) {
    score -= 70;
  }

  // Listing/grid items (not product detail page)
  if (className.includes('grid-item') || className.includes('list-item') ||
      className.includes('card') && !className.includes('product-card')) {
    score -= 40;
  }

  // Shipping/delivery prices
  if (text.includes('dostaw') || text.includes('shipping') ||
      text.includes('wysył')) {
    score -= 100;
  }

  return score;
}

/**
 * Score how likely an element is to be the PRODUCT NAME
 */
function scoreNameElement(el) {
  let score = 50;

  const tagName = el.tagName.toLowerCase();
  const className = (el.className || '').toLowerCase();

  // Heading tags are good
  if (tagName === 'h1') score += 40;
  else if (tagName === 'h2') score += 20;
  else if (tagName === 'h3') score += 10;

  // Good class names
  if (className.includes('product-name') || className.includes('product-title')) score += 35;
  if (className.includes('title') && className.includes('product')) score += 30;
  if (className.includes('name') && className.includes('product')) score += 30;
  if (className.includes('pdp-title')) score += 25;

  // Schema.org
  if (el.getAttribute('itemprop') === 'name') score += 50;

  // Visual prominence
  try {
    const style = window.getComputedStyle(el);
    const fontSize = parseFloat(style.fontSize);
    if (fontSize >= 24) score += 25;
    else if (fontSize >= 18) score += 15;

    const fontWeight = style.fontWeight;
    if (fontWeight >= 600 || fontWeight === 'bold') score += 10;
  } catch (e) {}

  // Position (product name usually near top)
  try {
    const rect = el.getBoundingClientRect();
    if (rect.top < 400) score += 15;
  } catch (e) {}

  // Penalties
  if (className.includes('related') || className.includes('similar') ||
      className.includes('recommend')) {
    score -= 50;
  }

  return score;
}

/**
 * Search DOM for elements containing a specific price value
 */
function findElementsWithPrice(priceValue) {
  const results = [];
  const priceStr = priceValue.toString();

  // Generate search patterns for the price in various international formats
  const patterns = [];

  const intPrice = Math.round(priceValue);
  const hasDecimals = priceValue !== intPrice;
  const decimalPart = hasDecimals ? (priceValue % 1).toFixed(2).substring(1) : ''; // ".00" or ".99"

  // Basic formats
  patterns.push(intPrice.toString()); // "4790"
  patterns.push(priceValue.toFixed(2)); // "4790.00"
  patterns.push(priceValue.toFixed(2).replace('.', ',')); // "4790,00"

  // Thousand separator formats (for prices >= 1000)
  if (intPrice >= 1000) {
    // Format with spaces: "4 790" / "4 790,00" / "4 790.00"
    const withSpaces = intPrice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    patterns.push(withSpaces);
    patterns.push(withSpaces + ',00');
    patterns.push(withSpaces + '.00');
    if (hasDecimals) {
      patterns.push(withSpaces + decimalPart);
      patterns.push(withSpaces + decimalPart.replace('.', ','));
    }

    // US format with comma thousands: "4,790" / "4,790.00"
    const withCommaThousands = intPrice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    patterns.push(withCommaThousands);
    patterns.push(withCommaThousands + '.00');
    if (hasDecimals) {
      patterns.push(withCommaThousands + decimalPart);
    }

    // German format with dot thousands: "4.790" / "4.790,00"
    const withDotThousands = intPrice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    patterns.push(withDotThousands);
    patterns.push(withDotThousands + ',00');
    if (hasDecimals) {
      patterns.push(withDotThousands + decimalPart.replace('.', ','));
    }
  }

  // Deduplicate
  const uniquePatterns = [...new Set(patterns)];

  // Search all text nodes
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    null,
    false
  );

  const seen = new Set();

  while (walker.nextNode()) {
    const textNode = walker.currentNode;
    const text = textNode.textContent || '';

    for (const pattern of uniquePatterns) {
      if (text.includes(pattern)) {
        let el = textNode.parentElement;

        // Walk up to find a meaningful container (not just a span inside span)
        while (el && ['SPAN', 'STRONG', 'B', 'EM'].includes(el.tagName) && el.parentElement) {
          const parent = el.parentElement;
          const parentText = parent.innerText || '';
          // If parent has roughly the same text, use parent
          if (parentText.length < text.length * 2) {
            el = parent;
          } else {
            break;
          }
        }

        if (el && !seen.has(el)) {
          seen.add(el);
          const score = scorePriceElement(el);
          results.push({
            element: el,
            selector: buildRobustSelector(el),
            score: score,
            text: el.innerText?.substring(0, 100) || '',
            matchedPattern: pattern
          });
        }
        break; // Found match for this text node
      }
    }
  }

  // Also check elements with data attributes
  document.querySelectorAll('[data-price], [data-product-price], [itemprop="price"]').forEach(el => {
    if (seen.has(el)) return;

    const content = el.getAttribute('content') || el.getAttribute('data-price') ||
                    el.getAttribute('data-product-price') || el.innerText || '';

    for (const pattern of uniquePatterns) {
      if (content.includes(pattern)) {
        seen.add(el);
        results.push({
          element: el,
          selector: buildRobustSelector(el),
          score: scorePriceElement(el) + 20, // Bonus for structured data
          text: el.innerText?.substring(0, 100) || content,
          matchedPattern: pattern
        });
        break;
      }
    }
  });

  // Sort by score (highest first)
  return results.sort((a, b) => b.score - a.score);
}

/**
 * Search DOM for elements containing a specific text (for product name)
 */
function findElementsWithText(searchText) {
  const results = [];
  const normalizedSearch = searchText.toLowerCase().trim();

  if (normalizedSearch.length < 3) return results;

  const seen = new Set();

  // Search in headings first (most likely to be product names)
  document.querySelectorAll('h1, h2, h3, [itemprop="name"], [class*="product-name"], [class*="product-title"]').forEach(el => {
    const text = (el.innerText || el.textContent || '').trim();
    const normalizedText = text.toLowerCase();

    if (normalizedText.includes(normalizedSearch) || normalizedSearch.includes(normalizedText)) {
      if (!seen.has(el)) {
        seen.add(el);
        results.push({
          element: el,
          selector: buildRobustSelector(el),
          score: scoreNameElement(el),
          text: text.substring(0, 150)
        });
      }
    }
  });

  // Also search all text nodes for exact matches
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    null,
    false
  );

  while (walker.nextNode()) {
    const textNode = walker.currentNode;
    const text = (textNode.textContent || '').trim();
    const normalizedText = text.toLowerCase();

    if (normalizedText.includes(normalizedSearch) && text.length < 200) {
      let el = textNode.parentElement;

      if (el && !seen.has(el)) {
        seen.add(el);
        results.push({
          element: el,
          selector: buildRobustSelector(el),
          score: scoreNameElement(el),
          text: text.substring(0, 150)
        });
      }
    }
  }

  return results.sort((a, b) => b.score - a.score);
}

/**
 * Search DOM for images with a specific URL
 */
function findElementsWithImage(imageUrl) {
  const results = [];

  if (!imageUrl) return results;

  // Normalize URL for comparison
  const normalizedUrl = imageUrl.toLowerCase().split('?')[0];

  document.querySelectorAll('img, [style*="background-image"], meta[property="og:image"], meta[name="twitter:image"]').forEach(el => {
    let elUrl = '';

    if (el.tagName === 'IMG') {
      elUrl = el.src || el.getAttribute('data-src') || '';
    } else if (el.tagName === 'META') {
      elUrl = el.content || '';
    } else {
      const style = el.style.backgroundImage || '';
      const match = style.match(/url\(['"]?([^'"]+)['"]?\)/);
      if (match) elUrl = match[1];
    }

    if (elUrl.toLowerCase().split('?')[0] === normalizedUrl) {
      results.push({
        element: el,
        selector: buildRobustSelector(el),
        score: 100,
        url: elUrl
      });
    }
  });

  return results;
}

/**
 * Main discovery function - finds selectors for corrected values
 */
function discoverSelectorsFromCorrections(originalData, correctedData) {
  const discoveries = {};

  console.log('[SAIVED Discovery] Analyzing corrections...', { originalData, correctedData });

  // Check price correction
  if (correctedData.unit_price != null &&
      correctedData.unit_price !== originalData.unit_price) {
    console.log('[SAIVED Discovery] Price was corrected:', originalData.unit_price, '→', correctedData.unit_price);

    const candidates = findElementsWithPrice(correctedData.unit_price);
    console.log('[SAIVED Discovery] Found price candidates:', candidates.length);

    if (candidates.length > 0) {
      discoveries.price = {
        corrected_value: correctedData.unit_price,
        original_value: originalData.unit_price,
        candidates: candidates.slice(0, 5).map(c => ({
          selector: c.selector,
          score: c.score,
          text: c.text,
          matched_pattern: c.matchedPattern
        }))
      };
      console.log('[SAIVED Discovery] Best price selector:', candidates[0].selector, 'score:', candidates[0].score);
    }
  }

  // Check name correction
  if (correctedData.name && correctedData.name !== originalData.name) {
    console.log('[SAIVED Discovery] Name was corrected:', originalData.name, '→', correctedData.name);

    const candidates = findElementsWithText(correctedData.name);

    if (candidates.length > 0) {
      discoveries.name = {
        corrected_value: correctedData.name,
        original_value: originalData.name,
        candidates: candidates.slice(0, 3).map(c => ({
          selector: c.selector,
          score: c.score,
          text: c.text
        }))
      };
      console.log('[SAIVED Discovery] Best name selector:', candidates[0].selector);
    }
  }

  // Check thumbnail correction
  if (correctedData.thumbnail_url &&
      correctedData.thumbnail_url !== originalData.thumbnail_url) {
    console.log('[SAIVED Discovery] Thumbnail was corrected');

    const candidates = findElementsWithImage(correctedData.thumbnail_url);

    if (candidates.length > 0) {
      discoveries.thumbnail_url = {
        corrected_value: correctedData.thumbnail_url,
        original_value: originalData.thumbnail_url,
        candidates: candidates.slice(0, 3).map(c => ({
          selector: c.selector,
          score: c.score,
          url: c.url
        }))
      };
    }
  }

  return discoveries;
}

// Try learned selector first, then fallback to heuristics
function tryLearnedSelector(field, fallbackFn) {
  const learnedSelector = learnedSelectors[field];
  if (learnedSelector) {
    const el = safeQuery(learnedSelector);
    if (el) {
      return { el, usedLearned: true, selector: learnedSelector };
    }
  }
  // Fallback to heuristic
  const result = fallbackFn();
  return { ...result, usedLearned: false };
}

function outerHtmlSample(el) {
  if (!el) return "";
  const html = el.outerHTML || "";
  // przytnij, żeby nie wysyłać kilometrowych stringów
  return html.length > 400 ? html.slice(0, 400) + "..." : html;
}

function buildCssSelector(el) {
  if (!el || !el.tagName) return "";
  let path = [];
  let node = el;

  while (node && node.nodeType === 1 && path.length < 5) {
    let selector = node.tagName.toLowerCase();

    // Handle meta tags with identifying attributes
    if (selector === "meta") {
      const prop = node.getAttribute("property");
      const name = node.getAttribute("name");
      const httpEquiv = node.getAttribute("http-equiv");
      if (prop) {
        selector = `meta[property="${prop}"]`;
        path.unshift(selector);
        break; // meta with property is unique enough
      } else if (name) {
        selector = `meta[name="${name}"]`;
        path.unshift(selector);
        break;
      } else if (httpEquiv) {
        selector = `meta[http-equiv="${httpEquiv}"]`;
        path.unshift(selector);
        break;
      }
    }

    if (node.id) {
      selector += "#" + node.id;
      path.unshift(selector);
      break;
    } else {
      if (node.className && typeof node.className === "string") {
        const classes = node.className
          .split(/\s+/)
          .filter(Boolean)
          .slice(0, 2);
        if (classes.length) {
          selector += "." + classes.join(".");
        }
      }
      path.unshift(selector);
      node = node.parentElement;
    }
  }

  return path.join(" ");
}

function extractProductInfo() {
  const url = location.href;
  const domain = location.hostname;

  // Track which fields used learned selectors
  const usedLearnedFor = {};

  // --- NAZWA ---
  let name = "";
  let nameEl = null;

  const nameResult = tryLearnedSelector("name", () => {
    // Heuristic fallback for name
    let el =
      safeQuery('meta[property="og:title"]') ||
      safeQuery('meta[name="twitter:title"]');

    if (el && el.content) {
      return { el, value: el.content.trim() };
    }

    // weź h1 z największym font-size
    const h1s = Array.from(document.querySelectorAll("h1"));
    if (h1s.length) {
      let best = h1s[0];
      let bestSize = parseFloat(getComputedStyle(best).fontSize) || 0;
      for (const h of h1s) {
        const size = parseFloat(getComputedStyle(h).fontSize) || 0;
        if (size > bestSize) {
          best = h;
          bestSize = size;
        }
      }
      return { el: best, value: best.innerText.trim() };
    }

    return { el: null, value: "" };
  });

  nameEl = nameResult.el;
  usedLearnedFor.name = nameResult.usedLearned;

  if (nameResult.usedLearned && nameEl) {
    // Extract value from learned selector element
    name = nameEl.content || nameEl.innerText || "";
    name = name.trim();
  } else {
    name = nameResult.value || "";
  }

  // --- CENA ---
  let priceText = "";
  let priceEl = null;

  const priceResult = tryLearnedSelector("price", () => {
    // Heuristic fallback for price
    const priceSelectors = [
      '[itemprop="price"]',
      '[data-price]',
      '[class*="price"]',
      '[class*="Price"]'
    ];

    for (const sel of priceSelectors) {
      const el = safeQuery(sel);
      if (el) {
        // Try multiple ways to extract price value
        const text = (
          el.getAttribute("data-price") ||
          el.getAttribute("data-value") ||
          el.getAttribute("content") ||
          el.value ||
          el.innerText ||
          ""
        ).trim();
        if (text && (/[\d]+[.,]\d{2}/.test(text) || /^\d+$/.test(text))) {
          return { el, value: text };
        }
      }
    }

    return { el: null, value: "" };
  });

  priceEl = priceResult.el;
  usedLearnedFor.price = priceResult.usedLearned;

  if (priceResult.usedLearned && priceEl) {
    // Try multiple ways to extract price value from the element
    priceText = (
      priceEl.getAttribute("data-price") ||    // data-price attribute (beliani.pl uses this)
      priceEl.getAttribute("data-value") ||    // data-value attribute
      priceEl.getAttribute("content") ||       // meta tags
      priceEl.value ||                         // input elements
      priceEl.innerText ||                     // regular elements
      ""
    ).trim();
  } else {
    priceText = priceResult.value || "";
  }

  let priceNumber = null;
  if (priceText) {
    priceNumber = parsePrice(priceText);
  }

  // --- MINIATURKA ---
  let thumbUrl = "";
  let thumbEl = null;

  const thumbResult = tryLearnedSelector("thumbnail_url", () => {
    // Heuristic fallback for thumbnail
    let el =
      safeQuery('meta[property="og:image"]') ||
      safeQuery('meta[name="twitter:image"]');

    if (el && el.content) {
      return { el, value: el.content.trim() };
    }

    const imgs = Array.from(document.images || []);
    if (imgs.length) {
      // weź największe img
      let best = imgs[0];
      let bestArea = best.naturalWidth * best.naturalHeight;
      for (const img of imgs) {
        const area = img.naturalWidth * img.naturalHeight;
        if (area > bestArea) {
          best = img;
          bestArea = area;
        }
      }
      return { el: best, value: best.src || "" };
    }

    return { el: null, value: "" };
  });

  thumbEl = thumbResult.el;
  usedLearnedFor.thumbnail = thumbResult.usedLearned;

  if (thumbResult.usedLearned && thumbEl) {
    thumbUrl = thumbEl.content || thumbEl.src || "";
    thumbUrl = thumbUrl.trim();
  } else {
    thumbUrl = thumbResult.value || "";
  }

  const selectors = {};
  const htmlSamples = {};

  if (nameEl) {
    selectors.name = nameResult.selector || buildCssSelector(nameEl);
    htmlSamples.name = outerHtmlSample(nameEl);
  }
  if (priceEl) {
    selectors.price = priceResult.selector || buildCssSelector(priceEl);
    htmlSamples.price = outerHtmlSample(priceEl);
  }
  if (thumbEl) {
    selectors.thumbnail = thumbResult.selector || buildCssSelector(thumbEl);
    htmlSamples.thumbnail = outerHtmlSample(thumbEl);
  }

  // Determine engine type based on whether learned selectors were used
  const hasLearned = Object.values(usedLearnedFor).some(v => v);
  const engine = hasLearned ? "learned-v1" : "heuristic-v1";

  const product = {
    name: name || "",
    unit_price: priceNumber,
    currency: "PLN",
    thumbnail_url: thumbUrl || "",
    external_url: url
  };

  const capture_context = {
    url,
    domain,
    selectors,
    html_samples: htmlSamples,
    engine,
    used_learned: usedLearnedFor
  };

  return { product, capture_context };
}

browserApi.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "SAIVED_SCRAPE_PAGE") {
    try {
      // Accept learned selectors from popup (if provided)
      if (message.learnedSelectors) {
        learnedSelectors = message.learnedSelectors;
        console.log("[SAIVED] Using learned selectors:", learnedSelectors);
      } else {
        learnedSelectors = {};
      }

      const data = extractProductInfo();
      sendResponse({ ok: true, data });
    } catch (e) {
      console.error("[SAIVED] błąd extractProductInfo:", e);
      sendResponse({ ok: false, error: String(e) });
    }
    return true; // async
  }

  // Handle discovery request - search DOM for corrected values
  if (message && message.type === "SAIVED_DISCOVER_SELECTORS") {
    try {
      const { originalData, correctedData } = message;
      const discoveries = discoverSelectorsFromCorrections(originalData, correctedData);
      sendResponse({ ok: true, discoveries });
    } catch (e) {
      console.error("[SAIVED] błąd discoverSelectors:", e);
      sendResponse({ ok: false, error: String(e) });
    }
    return true;
  }
});