# CLAUDE.md - SAIVED Browser Extension

## Project Overview

SAIVED Extension is a Manifest V3 browser extension for interior designers. It allows users to:
1. Visit any e-commerce product page
2. Click the extension to auto-scrape product info (name, price, image)
3. Select a project and section
4. Add the product to their cost estimate with one click

Works with the SAIVED Backend API.

## Tech Stack

- **Manifest**: V3 (Chrome/Firefox compatible)
- **Language**: Vanilla JavaScript (ES6+)
- **UI**: Plain HTML + CSS (no framework)
- **Communication**: Fetch API + chrome.runtime messaging

## Architecture

```
manifest.json          # Extension config
├── popup.html         # Main UI (when icon clicked)
├── popup.js           # UI logic + API calls
└── content-script.js  # Runs on every page, scrapes product data
```

**No background service worker** - all logic in popup and content script.

## How Scraping Works (content-script.js)

The extension uses a **two-tier scraping strategy**:

### 1. Learned Selectors (Priority)
Before scraping, popup.js fetches learned selectors from the backend:
```
GET /api/v1/selectors?domain=ikea.pl
→ { selectors: { name: "h1.product-title", price: ".price-box" } }
```

If a learned selector exists for a field, the extension tries it first.

### 2. Heuristic Fallbacks
If no learned selector exists or it fails, heuristics are used:

**Product Name**:
1. Try `<meta property="og:title">` or `<meta name="twitter:title">`
2. Fallback: Largest `<h1>` by computed font-size

**Price**:
1. Try `[itemprop="price"]` (Schema.org)
2. Try `[data-price]`
3. Try `[class*="price"]` or `[class*="Price"]`
4. Parse with regex: extracts `329,99` or `329.99` format

**Thumbnail**:
1. Try `<meta property="og:image">` or `<meta name="twitter:image">`
2. Fallback: Largest image by pixel area

### Capture Context (for learning)
For each field, stores:
- CSS selector path (max 5 levels, stops at ID)
- HTML sample (truncated to 400 chars)
- Engine type: `"heuristic-v1"` or `"learned-v1"`
- `used_learned`: which fields used learned selectors

## Message Flow

```
Popup opens
    ↓
Extract domain from current tab URL
    ↓
Fetch learned selectors: GET /api/v1/selectors?domain=...
    ↓
Popup sends: { type: "SAIVED_SCRAPE_PAGE", learnedSelectors: {...} }
    ↓
Content script scrapes DOM (learned selectors first, then heuristics)
    ↓
Content script returns: { ok: true, data: { product, capture_context } }
    ↓
Popup displays preview, user edits if needed
    ↓
User clicks "Dodaj do SAIVED"
    ↓
POST to /api/v1/project_sections/:id/items
    ↓
Backend saves ProductCaptureSample and triggers AnalyzeCaptureSampleJob
    ↓
Job compares raw vs final, updates DomainSelector success/failure counts
```

## API Communication (popup.js)

**Config**:
```javascript
const API_BASE_URL = "https://saived.ai";
// Token stored in chrome.storage.local, user enters via config screen
```

**Endpoints Used**:
- `GET /api/v1/selectors?domain=...` - Fetch learned selectors for domain
- `GET /api/v1/projects` - List projects for dropdown
- `GET /api/v1/projects/:id` - Get sections for selected project
- `POST /api/v1/project_sections/:id/items` - Add product item

## Storage

**chrome.storage.local**:
- `lastProjectId` - Remembers last selected project
- `lastSectionId` - Remembers last selected section

No other persistent storage.

## UI Structure (popup.html)

1. **Header**: "SAIVED" title + domain pill
2. **Project/Section dropdowns**: With refresh button
3. **Product preview card**: Thumbnail, name, URL, price
4. **Edit form**:
   - Product name (required)
   - Notes (optional)
   - Quantity + Price (row)
   - Status dropdown + Discount field
   - Thumbnail URL
   - Product link
5. **Submit button**: "Dodaj do SAIVED"
6. **Status messages**: Success/error feedback

**All UI text is in Polish.**

## Permissions (manifest.json)

```json
{
  "permissions": ["storage", "activeTab", "scripting"],
  "host_permissions": ["https://saived.ai/*", "https://*.saived.ai/*"]
}
```

Content script runs on `<all_urls>` at `document_idle`.

## Current State & Known Issues

**Working**:
- Scraping from most e-commerce sites
- Project/section selection
- Adding items to backend
- Remembers last selection
- Learning system integration (fetches and uses learned selectors)

**Limitations**:
- Price parsing fails on some sites (non-standard formats)
- Currency hardcoded to PLN

**Future Plans**:
- Grammarly-style auth flow:
  1. Extension shows "Login" button if no token
  2. Opens SAIVED login page
  3. After login, token auto-transfers to extension
- Better price extraction with ML/heuristics
- Support for more currencies

## Development

1. Load unpacked extension in Chrome (`chrome://extensions`)
2. Enable Developer Mode
3. Point to `saived-extension` folder
4. Get your API token from https://saived.ai/workspace (click user dropdown → copy token)
5. Paste token into extension config screen

## Key Functions

**content-script.js**:
- `extractProductInfo()` - Main scraping function
- `tryLearnedSelector(field, fallbackFn)` - Try learned selector, fallback to heuristic
- `buildCssSelector()` - Builds selector path for learning

**popup.js**:
- `fetchLearnedSelectors(domain)` - Fetch learned selectors from backend API
- `loadProjects()` - Fetches projects from API
- `populateSectionsForSelectedProject()` - Fetches sections for project
- Add item click handler - POSTs item to backend

## Polish UI Labels

- "Dodaj do SAIVED" = Add to SAIVED
- "Pobieram dane strony..." = Fetching page data...
- "Pozycja dodana" = Item added
- "Wybierz projekt" = Select project
- "Wybierz sekcję" = Select section
- "Propozycja/Wybrane/Zamówione" = Proposal/Selected/Ordered (status options)
