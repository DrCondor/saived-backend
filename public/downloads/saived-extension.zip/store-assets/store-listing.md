# Chrome Web Store Listing - SAIVED

## Nazwa (Name)
SAIVED - Kosztorysy dla Architektów Wnętrz

## Krótki opis (Short Description) - max 132 znaki
Zbieraj produkty ze sklepów jednym kliknięciem. Automatyczne wykrywanie cen i organizacja w projekty dla architektów wnętrz.

## Pełny opis (Full Description)

SAIVED to narzędzie stworzone specjalnie dla architektów wnętrz i projektantów, którzy chcą skończyć z chaosem arkuszy Excel i dziesiątkami zakładek w przeglądarce.

🛋️ JAK TO DZIAŁA?

1. Przeglądasz sklep internetowy (IKEA, Westwing, BoConcept, dowolny inny)
2. Znajdujesz produkt, który chcesz dodać do projektu
3. Klikasz ikonę SAIVED - rozszerzenie automatycznie wykrywa nazwę, cenę i zdjęcie
4. Wybierasz projekt i sekcję (np. "Apartament Mokotów" → "Salon")
5. Gotowe! Produkt jest w Twoim kosztorysie

✨ GŁÓWNE FUNKCJE

• Automatyczne wykrywanie danych produktu - nie musisz nic przepisywać
• Obsługa dowolnego sklepu internetowego - działa wszędzie
• Organizacja w projekty i sekcje - każde pomieszczenie ma swoje miejsce
• Automatyczne sumowanie kosztów - zawsze wiesz, ile wydajesz
• Statusy produktów - propozycja, wybrane, zamówione
• Eksport do PDF - profesjonalne kosztorysy dla klientów

💼 DLA KOGO?

• Architektów wnętrz
• Projektantów wnętrz
• Home stagerów
• Dekoratorów
• Każdego, kto zbiera produkty z różnych sklepów do projektów

🔒 BEZPIECZEŃSTWO

• Twoje dane są bezpiecznie przechowywane na serwerach w UE
• Nie sprzedajemy Twoich danych
• Stosujemy szyfrowanie HTTPS

🚀 ZACZNIJ JUŻ TERAZ

1. Zainstaluj rozszerzenie
2. Załóż konto na saived.ai
3. Skopiuj token API z panelu użytkownika
4. Wklej token w rozszerzeniu
5. Zacznij zbierać produkty!

Pytania? Napisz do nas: kontakt@saived.ai

---

## Kategoria (Category)
Productivity

## Język (Language)
Polski (Polish)

## Tagi (jeśli dostępne)
- kosztorys
- architektura wnętrz
- projektowanie
- produkty
- meble
- design

## Strona domowa (Homepage URL)
https://saived.ai

## URL wsparcia (Support URL)
https://saived.ai/about

## Prywatność (Privacy Policy URL)
https://saived.ai/privacy
