# Polityka Prywatności - SAIVED

*Ostatnia aktualizacja: 5 stycznia 2026*

## 1. Informacje ogólne

SAIVED ("my", "nas", "nasze") szanuje Twoją prywatność. Niniejsza polityka prywatności wyjaśnia, jakie dane zbieramy, jak je wykorzystujemy i jakie masz prawa.

## 2. Administrator danych

Administratorem Twoich danych osobowych jest:
- Nazwa: SAIVED
- Email: kontakt@saived.ai
- Adres: Szczecin, Polska

## 3. Jakie dane zbieramy

### 3.1 Dane konta
- Adres email (do logowania i komunikacji)
- Zaszyfrowane hasło

### 3.2 Dane projektów
- Nazwy projektów i sekcji
- Informacje o produktach (nazwy, ceny, linki, zdjęcia)
- Te dane są wprowadzane przez Ciebie i przechowywane na Twoim koncie

### 3.3 Dane techniczne
- Domena strony, z której dodajesz produkt (np. "ikea.pl")
- Selektory CSS użyte do pobrania danych produktu
- Te dane są anonimowe i służą do ulepszania automatycznego wykrywania produktów

### 3.4 Czego NIE zbieramy
- Nie zbieramy historii przeglądania
- Nie zbieramy danych osobowych ze stron, które odwiedzasz
- Nie zbieramy danych płatniczych (obsługiwane przez Stripe)

## 4. Jak wykorzystujemy dane

- **Świadczenie usługi**: Przechowywanie Twoich projektów i produktów
- **Ulepszanie wykrywania**: Anonimowe dane o selektorach pomagają lepiej wykrywać produkty
- **Komunikacja**: Wysyłanie ważnych informacji o koncie (np. zmiany w regulaminie)

## 5. Udostępnianie danych

Nie sprzedajemy Twoich danych. Udostępniamy je tylko:
- **Stripe**: Do obsługi płatności
- **Fly.io**: Hosting serwerów (serwery w UE)
- **Na żądanie prawa**: Jeśli wymaga tego prawo

## 6. Bezpieczeństwo

- Wszystkie dane przesyłane są przez szyfrowane połączenie HTTPS
- Hasła są hashowane i solone
- Dostęp do bazy danych jest ograniczony

## 7. Przechowywanie danych

- Dane są przechowywane na serwerach w Unii Europejskiej
- Dane konta przechowujemy do momentu usunięcia konta
- Po usunięciu konta, dane są usuwane w ciągu 30 dni

## 8. Twoje prawa (RODO)

Masz prawo do:
- **Dostępu**: Możesz zobaczyć swoje dane w panelu użytkownika
- **Poprawiania**: Możesz edytować swoje dane w ustawieniach
- **Usunięcia**: Możesz usunąć konto i wszystkie dane
- **Eksportu**: Możesz pobrać swoje dane w formacie JSON
- **Sprzeciwu**: Możesz sprzeciwić się przetwarzaniu danych marketingowych

Aby skorzystać z tych praw, napisz na: kontakt@saived.ai

## 9. Pliki cookies

Używamy tylko niezbędnych cookies do:
- Utrzymania sesji logowania
- Zapamiętania preferencji

Nie używamy cookies reklamowych ani śledzących.

## 10. Rozszerzenie przeglądarki

Rozszerzenie SAIVED:
- Działa tylko gdy je aktywujesz (kliknięcie ikony)
- Pobiera dane tylko z aktywnej karty, gdy klikniesz "Dodaj"
- Nie działa w tle, nie monitoruje przeglądania
- Przechowuje tylko token API lokalnie w przeglądarce

## 11. Zmiany w polityce

O istotnych zmianach poinformujemy emailem lub w aplikacji. Dalsze korzystanie z usługi oznacza akceptację zmian.

## 12. Kontakt

Pytania dotyczące prywatności:
- Email: kontakt@saived.ai
- Adres: Szczecin, Polska

---

*Ta polityka prywatności jest dostępna również pod adresem: https://saived.ai/privacy*
