const browserApi = typeof browser !== "undefined" ? browser : chrome;

// Always use floating mode for now (side panel support coming later)
browserApi.action.onClicked.addListener(async (tab) => {
  browserApi.tabs.sendMessage(tab.id, { type: "SAIVED_TOGGLE" });
});
