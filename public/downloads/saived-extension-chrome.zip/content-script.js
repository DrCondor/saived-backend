// content-script.js
const browserApi = typeof browser !== "undefined" ? browser : chrome;

// Learned selectors from the backend (passed via message)
let learnedSelectors = {};

// Price Picker Mode
let pricePickerOverlay = null;
let pricePickerActive = false;

// Image Picker Mode
let imagePickerOverlay = null;
let imagePickerActive = false;

// ============================================================
// IFRAME HOST - Persistent floating window
// ============================================================

let saivedHost = null;
let saivedContainer = null;
let saivedIframe = null;
let saivedPill = null;
let saivedState = "hidden"; // "visible" | "minimized" | "hidden"

function initIframeHost() {
  createIframeHost();
}

function createIframeHost() {
  if (saivedHost) return;

  saivedHost = document.createElement("div");
  saivedHost.id = "saived-host";
  const shadow = saivedHost.attachShadow({ mode: "closed" });

  const styles = document.createElement("style");
  styles.textContent = `
    .saived-container {
      position: fixed;
      top: 20px;
      right: 20px;
      width: 380px;
      max-height: calc(100vh - 40px);
      z-index: 2147483646;
      display: none;
      flex-direction: column;
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(0, 0, 0, 0.08);
      overflow: hidden;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
    }
    .saived-container.visible {
      display: flex;
    }
    .saived-titlebar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 12px;
      background: linear-gradient(135deg, #111827, #1f2937);
      color: white;
      cursor: grab;
      user-select: none;
      flex-shrink: 0;
    }
    .saived-titlebar:active {
      cursor: grabbing;
    }
    .saived-titlebar-left {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      font-weight: 600;
      letter-spacing: -0.01em;
    }
    .saived-titlebar-logo {
      width: 20px;
      height: 20px;
      border-radius: 4px;
    }
    .saived-titlebar-btns {
      display: flex;
      gap: 4px;
    }
    .saived-titlebar-btn {
      width: 24px;
      height: 24px;
      border: none;
      border-radius: 6px;
      background: rgba(255, 255, 255, 0.1);
      color: rgba(255, 255, 255, 0.7);
      font-size: 14px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s;
    }
    .saived-titlebar-btn:hover {
      background: rgba(255, 255, 255, 0.2);
      color: white;
    }
    .saived-iframe {
      width: 100%;
      height: 750px;
      border: none;
      background: white;
    }
    .saived-pill {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 44px;
      height: 44px;
      border-radius: 50%;
      background: linear-gradient(135deg, #111827, #1f2937);
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      cursor: pointer;
      display: none;
      align-items: center;
      justify-content: center;
      z-index: 2147483646;
      transition: transform 0.15s;
    }
    .saived-pill:hover {
      transform: scale(1.1);
    }
    .saived-pill.visible {
      display: flex;
    }
    .saived-pill img {
      width: 24px;
      height: 24px;
      border-radius: 4px;
    }
  `;

  const container = document.createElement("div");
  container.className = "saived-container";

  const logoUrl = browserApi.runtime.getURL("logo.jpg");

  // Titlebar
  const titlebar = document.createElement("div");
  titlebar.className = "saived-titlebar";
  titlebar.innerHTML = `
    <div class="saived-titlebar-left">
      <img src="${logoUrl}" class="saived-titlebar-logo" alt="">
      <span>SAIVED</span>
    </div>
    <div class="saived-titlebar-btns">
      <button class="saived-titlebar-btn saived-minimize-btn" title="Minimalizuj">—</button>
      <button class="saived-titlebar-btn saived-close-btn" title="Zamknij">✕</button>
    </div>
  `;

  // Iframe
  const iframe = document.createElement("iframe");
  iframe.className = "saived-iframe";
  iframe.src = browserApi.runtime.getURL("popup.html");

  container.appendChild(titlebar);
  container.appendChild(iframe);

  // Floating pill
  const pill = document.createElement("div");
  pill.className = "saived-pill";
  pill.innerHTML = `<img src="${logoUrl}" alt="SAIVED">`;

  shadow.appendChild(styles);
  shadow.appendChild(container);
  shadow.appendChild(pill);

  document.body.appendChild(saivedHost);

  saivedContainer = container;
  saivedIframe = iframe;
  saivedPill = pill;

  // Event handlers
  titlebar.querySelector(".saived-minimize-btn").addEventListener("click", (e) => {
    e.stopPropagation();
    minimizeSaived();
  });

  titlebar.querySelector(".saived-close-btn").addEventListener("click", (e) => {
    e.stopPropagation();
    closeSaived();
  });

  pill.addEventListener("click", () => {
    showSaived();
  });

  // Drag to reposition
  let isDragging = false;
  let dragStartX, dragStartY, containerStartX, containerStartY;

  titlebar.addEventListener("mousedown", (e) => {
    if (e.target.closest(".saived-titlebar-btn")) return;
    isDragging = true;
    dragStartX = e.clientX;
    dragStartY = e.clientY;
    const rect = container.getBoundingClientRect();
    containerStartX = rect.left;
    containerStartY = rect.top;
    // Disable iframe pointer events so mouse events aren't swallowed during drag
    iframe.style.pointerEvents = "none";
    e.preventDefault();
  });

  document.addEventListener("mousemove", (e) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStartX;
    const dy = e.clientY - dragStartY;

    // Clamp to viewport bounds
    const cw = container.offsetWidth;
    const ch = container.offsetHeight;
    const newX = Math.max(0, Math.min(window.innerWidth - cw, containerStartX + dx));
    const newY = Math.max(0, Math.min(window.innerHeight - ch, containerStartY + dy));

    container.style.left = newX + "px";
    container.style.top = newY + "px";
    container.style.right = "auto";
  });

  document.addEventListener("mouseup", () => {
    if (isDragging) {
      isDragging = false;
      iframe.style.pointerEvents = "";
    }
  });

  // Listen for postMessage from iframe
  window.addEventListener("message", (event) => {
    if (!event.data || !event.data.type) return;
    // Validate origin — accept messages from the extension origin
    const extOrigin = new URL(browserApi.runtime.getURL("")).origin;
    if (event.origin !== extOrigin) return;

    if (event.data.type === "SAIVED_MINIMIZE") {
      minimizeSaived();
    } else if (event.data.type === "SAIVED_CLOSE") {
      closeSaived();
    } else if (event.data.type === "SAIVED_START_PRICE_PICKER") {
      minimizeSaived();
      startPricePickerMode();
    } else if (event.data.type === "SAIVED_START_IMAGE_PICKER") {
      minimizeSaived();
      startImagePickerMode();
    } else if (event.data.type === "SAIVED_GET_DOMAIN") {
      // Reply with the current page domain
      if (saivedIframe) {
        saivedIframe.contentWindow.postMessage({
          type: "SAIVED_DOMAIN_RESPONSE",
          domain: location.hostname
        }, "*");
      }
    } else if (event.data.type === "SAIVED_RESIZE") {
      // Auto-resize iframe to fit content — no whitespace, no scrolling
      if (saivedIframe && event.data.height) {
        const maxH = window.innerHeight - 60; // leave room for titlebar + margins
        saivedIframe.style.height = Math.min(event.data.height, maxH) + "px";
      }
    } else if (event.data.type === "SAIVED_REQUEST_SCRAPE") {
      // Content script scrapes the page and sends result back to iframe
      handleIframeScrapeRequest(event.data.learnedSelectors || {});
    }
  });
}

function showSaived() {
  if (!saivedContainer) return;
  saivedContainer.classList.add("visible");
  saivedPill.classList.remove("visible");
  saivedState = "visible";
}

function minimizeSaived() {
  if (!saivedContainer) return;
  saivedContainer.classList.remove("visible");
  saivedPill.classList.add("visible");
  saivedState = "minimized";
}

function closeSaived() {
  if (!saivedContainer) return;
  saivedContainer.classList.remove("visible");
  saivedPill.classList.remove("visible");
  saivedState = "hidden";
}

function toggleSaived() {
  if (saivedState === "visible") {
    minimizeSaived();
  } else {
    showSaived();
  }
}

function handleIframeScrapeRequest(passedLearnedSelectors) {
  if (!saivedIframe) return;

  try {
    // Apply learned selectors (fetched by the iframe which has CORS access)
    learnedSelectors = passedLearnedSelectors || {};
    console.log("[SAIVED] Iframe scrape with learned selectors:", Object.keys(learnedSelectors).length ? learnedSelectors : "(none)");
    const data = extractProductInfo();
    console.log("[SAIVED] Scraped result:", { name: data.product.name, price: data.product.unit_price, engine: data.capture_context.engine });

    // Send result back to iframe
    saivedIframe.contentWindow.postMessage({
      type: "SAIVED_SCRAPE_RESULT",
      product: data.product,
      capture_context: data.capture_context
    }, "*");
  } catch (e) {
    console.error("[SAIVED] Iframe scrape error:", e);
  }
}

// Initialize iframe host when content script loads
initIframeHost();

// ============================================================
// CATEGORY DETECTION - Keywords for automatic category assignment
// ============================================================

const CATEGORY_KEYWORDS = {
  meble: {
    keywords: ['furniture', 'meble', 'sofa', 'kanapa', 'krzesło', 'chair', 'stół', 'table',
               'szafa', 'wardrobe', 'łóżko', 'bed', 'fotel', 'armchair', 'komoda', 'dresser',
               'regał', 'shelf', 'biurko', 'desk', 'szafka', 'cabinet', 'stolik', 'ława',
               'witryna', 'kredens', 'garderoba', 'tapczan', 'wersalka', 'narożnik', 'pufa'],
    weight: 1.0
  },
  tkaniny: {
    keywords: ['textile', 'fabric', 'tkaniny', 'zasłony', 'curtain', 'firany', 'poduszka',
               'pillow', 'koc', 'blanket', 'pled', 'dywan', 'rug', 'carpet', 'pościel',
               'bedding', 'obrus', 'tablecloth', 'narzuta', 'throw', 'roleta', 'żaluzje',
               'materac', 'mattress', 'kołdra', 'prześcieradło'],
    weight: 1.0
  },
  dekoracje: {
    keywords: ['decor', 'decoration', 'dekoracje', 'wazon', 'vase', 'ramka', 'frame',
               'świecznik', 'candle', 'ozdoba', 'ornament', 'figurka', 'figurine',
               'lustro', 'mirror', 'zegar', 'clock', 'doniczka', 'pot', 'kosz',
               'obraz', 'plakat', 'poster', 'rzeźba', 'sculpture'],
    weight: 1.0
  },
  armatura_i_ceramika: {
    keywords: ['bathroom', 'łazienka', 'armatura', 'ceramika', 'umywalka', 'sink',
               'wanna', 'bathtub', 'prysznic', 'shower', 'bateria', 'faucet', 'tap',
               'toaleta', 'toilet', 'bidet', 'kabina', 'płytki', 'tiles', 'sedes',
               'brodzik', 'deszczownica', 'kran', 'zlew', 'zlewozmywak'],
    weight: 1.0
  },
  oswietlenie: {
    keywords: ['lighting', 'light', 'lamp', 'oświetlenie', 'lampa', 'żyrandol',
               'chandelier', 'kinkiet', 'sconce', 'plafon', 'ceiling', 'led',
               'żarówka', 'bulb', 'abażur', 'lampshade', 'reflektor', 'spotlight',
               'taśma led', 'oprawa', 'lampka'],
    weight: 1.0
  },
  okladziny_scienne: {
    keywords: ['wallpaper', 'tapeta', 'okładziny', 'ścienne', 'farba', 'paint',
               'panele', 'panel', 'tynk', 'plaster', 'cegła', 'brick', 'boazeria',
               'glazura', 'terakota', 'gres', 'lastryko', 'stiuk'],
    weight: 1.0
  },
  agd: {
    keywords: ['appliance', 'agd', 'pralka', 'washer', 'lodówka', 'fridge', 'refrigerator',
               'zmywarka', 'dishwasher', 'piekarnik', 'oven', 'mikrofalówka', 'microwave',
               'kuchenka', 'stove', 'okap', 'hood', 'ekspres', 'coffee', 'suszarka',
               'płyta indukcyjna', 'płyta grzewcza', 'robot kuchenny', 'toster'],
    weight: 1.0
  }
};

const CATEGORY_LABELS = {
  meble: 'MEBLE',
  tkaniny: 'TKANINY',
  dekoracje: 'DEKORACJE',
  armatura_i_ceramika: 'ARMATURA I CERAMIKA',
  oswietlenie: 'OŚWIETLENIE',
  okladziny_scienne: 'OKŁADZINY ŚCIENNE',
  agd: 'AGD'
};

function safeQuery(selector) {
  try {
    return document.querySelector(selector) || null;
  } catch (e) {
    return null;
  }
}

// ============================================================
// INTERNATIONAL PRICE PARSER
// ============================================================

/**
 * Intelligent price parser that handles international formats:
 * - "329,99" → 329.99 (Polish/European - comma as decimal)
 * - "329.99" → 329.99 (US/UK - dot as decimal)
 * - "4,790.00" → 4790.00 (US with thousands separator)
 * - "4 790,00" → 4790.00 (European with space thousands)
 * - "4.790,00" → 4790.00 (German with dot thousands)
 * - "1 234 567,89" → 1234567.89 (European large numbers)
 */
function parsePrice(text) {
  if (!text) return null;

  // Remove currency symbols, whitespace around edges, and common noise
  let cleaned = text
    .replace(/[zł$€£¥₽PLN\s]+$/gi, '') // Remove trailing currency
    .replace(/^[zł$€£¥₽PLN\s]+/gi, '') // Remove leading currency
    .trim();

  // Extract just the number part (digits, dots, commas, spaces)
  const numberMatch = cleaned.match(/[\d\s.,]+/);
  if (!numberMatch) return null;

  let numStr = numberMatch[0].trim();

  // Remove all spaces (thousand separators in some formats)
  numStr = numStr.replace(/\s/g, '');

  // Now we have something like: "4,790.00" or "4.790,00" or "329,99" or "329.99"

  // Count dots and commas
  const dots = (numStr.match(/\./g) || []).length;
  const commas = (numStr.match(/,/g) || []).length;

  // Determine the decimal separator
  let decimalSep = null;
  let thousandsSep = null;

  if (dots === 0 && commas === 0) {
    // Just digits, no decimals
    const parsed = parseInt(numStr, 10);
    return isNaN(parsed) ? null : parsed;
  }

  if (dots === 1 && commas === 0) {
    // Only dot: check if it's decimal or thousands
    const afterDot = numStr.split('.')[1];
    if (afterDot.length === 2) {
      decimalSep = '.'; // "329.99" → decimal
    } else if (afterDot.length === 3) {
      thousandsSep = '.'; // "4.790" → thousands
    } else {
      decimalSep = '.'; // Default to decimal
    }
  } else if (commas === 1 && dots === 0) {
    // Only comma: check if it's decimal or thousands
    const afterComma = numStr.split(',')[1];
    if (afterComma.length === 2) {
      decimalSep = ','; // "329,99" → decimal
    } else if (afterComma.length === 3) {
      thousandsSep = ','; // "4,790" → thousands
    } else {
      decimalSep = ','; // Default to decimal
    }
  } else if (dots >= 1 && commas >= 1) {
    // Both present: last separator is decimal
    const lastDotPos = numStr.lastIndexOf('.');
    const lastCommaPos = numStr.lastIndexOf(',');

    if (lastDotPos > lastCommaPos) {
      // "4,790.00" → dot is decimal, comma is thousands
      decimalSep = '.';
      thousandsSep = ',';
    } else {
      // "4.790,00" → comma is decimal, dot is thousands
      decimalSep = ',';
      thousandsSep = '.';
    }
  } else if (dots > 1) {
    // Multiple dots: "1.234.567" → dots are thousands, no decimal
    thousandsSep = '.';
  } else if (commas > 1) {
    // Multiple commas: "1,234,567" → commas are thousands, no decimal
    thousandsSep = ',';
  }

  // Build the normalized number string
  if (thousandsSep) {
    numStr = numStr.split(thousandsSep).join('');
  }
  if (decimalSep === ',') {
    numStr = numStr.replace(',', '.');
  }

  const parsed = parseFloat(numStr);
  return isNaN(parsed) ? null : parsed;
}

// ============================================================
// SMART SELECTOR DISCOVERY
// When user corrects a value, search DOM to find the right element
// ============================================================

/**
 * Build a robust, reusable CSS selector for an element
 * Prefers: ID > unique class combinations > structural path
 */
function buildRobustSelector(el) {
  if (!el || !el.tagName) return "";

  // Strategy 1: If element has ID, use it
  if (el.id) {
    return `#${el.id}`;
  }

  // Strategy 2: Try to find a unique class combination
  if (el.className && typeof el.className === 'string') {
    const classes = el.className.split(/\s+/).filter(c => {
      // Filter out dynamic/hash classes
      return c &&
             !c.match(/^[a-f0-9]{6,}$/i) && // hex hashes
             !c.match(/^\d+$/) &&            // pure numbers
             !c.match(/^_/) &&               // underscore prefix (often generated)
             c.length < 30;                  // not too long
    });

    if (classes.length > 0) {
      // Try progressively more specific class combinations
      for (let i = 1; i <= Math.min(classes.length, 3); i++) {
        const selector = el.tagName.toLowerCase() + '.' + classes.slice(0, i).join('.');
        const matches = document.querySelectorAll(selector);
        if (matches.length === 1) {
          return selector;
        }
      }
    }
  }

  // Strategy 3: Build path from nearest ID or unique parent
  let path = [];
  let node = el;
  let foundAnchor = false;

  while (node && node.nodeType === 1 && path.length < 6) {
    let part = node.tagName.toLowerCase();

    if (node.id) {
      part = `#${node.id}`;
      path.unshift(part);
      foundAnchor = true;
      break;
    }

    // Add meaningful classes
    if (node.className && typeof node.className === 'string') {
      const goodClasses = node.className.split(/\s+/).filter(c => {
        return c &&
               c.length < 25 &&
               !c.match(/^[a-f0-9]{6,}$/i) &&
               (c.includes('price') || c.includes('product') || c.includes('title') ||
                c.includes('name') || c.includes('detail') || c.includes('main') ||
                c.includes('info') || c.includes('content') || c.includes('box'));
      }).slice(0, 2);

      if (goodClasses.length > 0) {
        part += '.' + goodClasses.join('.');
      }
    }

    path.unshift(part);
    node = node.parentElement;
  }

  const selector = path.join(' > ');

  // Verify selector works and is reasonably unique
  try {
    const matches = document.querySelectorAll(selector);
    if (matches.length <= 3) {
      return selector;
    }
  } catch (e) {}

  // Fallback to original simple selector
  return buildCssSelector(el);
}

/**
 * Score how likely an element is to be the MAIN PRODUCT PRICE (not promo, not old price)
 */
function scorePriceElement(el) {
  let score = 50; // Base score

  const className = (el.className || '').toLowerCase();
  const id = (el.id || '').toLowerCase();
  const text = (el.innerText || '').toLowerCase();

  // === POSITIVE SIGNALS ===

  // Good class names
  if (className.includes('price') && className.includes('product')) score += 35;
  if (className.includes('price') && className.includes('main')) score += 30;
  if (className.includes('price') && className.includes('current')) score += 30;
  if (className.includes('price') && className.includes('final')) score += 25;
  if (className.includes('price') && className.includes('sale')) score += 20;
  if (className.includes('product-price')) score += 25;
  if (className.includes('actual-price')) score += 25;
  if (id.includes('price')) score += 20;

  // Schema.org markup (very reliable)
  if (el.getAttribute('itemprop') === 'price') score += 50;
  if (el.hasAttribute('data-price')) score += 30;
  if (el.hasAttribute('data-product-price')) score += 35;

  // Check parent chain for product context
  let parent = el.parentElement;
  let depth = 0;
  while (parent && depth < 6) {
    const parentClass = (parent.className || '').toLowerCase();
    const parentId = (parent.id || '').toLowerCase();

    if (parentClass.includes('product-detail') || parentClass.includes('product-info') ||
        parentClass.includes('product-main') || parentClass.includes('pdp-')) {
      score += 30;
      break;
    }
    if (parentId.includes('product')) score += 20;

    // Penalty for being inside promotional/teaser areas
    if (parentClass.includes('teaser') || parentClass.includes('promo') ||
        parentClass.includes('carousel') || parentClass.includes('slider') ||
        parentClass.includes('recommendation') || parentClass.includes('related')) {
      score -= 60;
      break;
    }

    parent = parent.parentElement;
    depth++;
  }

  // Visual prominence
  try {
    const style = window.getComputedStyle(el);
    const fontSize = parseFloat(style.fontSize);
    if (fontSize >= 24) score += 20;
    else if (fontSize >= 18) score += 10;

    // Good colors (dark text usually = main price)
    const color = style.color;
    if (color.includes('0, 0, 0') || color.includes('17, 24, 39')) score += 5;
  } catch (e) {}

  // Position on page (main product price usually in upper portion)
  try {
    const rect = el.getBoundingClientRect();
    if (rect.top > 100 && rect.top < 700) score += 15;
    if (rect.left > 200) score += 5; // Usually not in left sidebar
  } catch (e) {}

  // === NEGATIVE SIGNALS ===

  // Old/crossed-out price
  if (className.includes('old') || className.includes('was') ||
      className.includes('regular') || className.includes('original') ||
      className.includes('before') || className.includes('crossed') ||
      className.includes('line-through')) {
    score -= 80;
  }

  // Check for strikethrough style
  try {
    const style = window.getComputedStyle(el);
    if (style.textDecoration.includes('line-through')) score -= 100;
  } catch (e) {}

  // Promotional/teaser elements
  if (className.includes('teaser') || className.includes('promo') ||
      className.includes('banner') || className.includes('widget') ||
      className.includes('spot') || className.includes('ad-')) {
    score -= 70;
  }

  // Listing/grid items (not product detail page)
  if (className.includes('grid-item') || className.includes('list-item') ||
      className.includes('card') && !className.includes('product-card')) {
    score -= 40;
  }

  // Shipping/delivery prices
  if (text.includes('dostaw') || text.includes('shipping') ||
      text.includes('wysył')) {
    score -= 100;
  }

  // Discount percentages (e.g. "-26.64%")
  if (text.includes('%')) {
    score -= 100;
  }

  // Discount/reduction class names
  if (className.includes('discount') || className.includes('rabat') ||
      className.includes('reduction') || className.includes('saving') ||
      className.includes('badge') || className.includes('tag')) {
    score -= 60;
  }

  return score;
}

/**
 * Score how likely an element is to be the PRODUCT NAME
 */
function scoreNameElement(el) {
  let score = 50;

  const tagName = el.tagName.toLowerCase();
  const className = (el.className || '').toLowerCase();

  // Heading tags are good
  if (tagName === 'h1') score += 40;
  else if (tagName === 'h2') score += 20;
  else if (tagName === 'h3') score += 10;

  // Good class names
  if (className.includes('product-name') || className.includes('product-title')) score += 35;
  if (className.includes('title') && className.includes('product')) score += 30;
  if (className.includes('name') && className.includes('product')) score += 30;
  if (className.includes('pdp-title')) score += 25;

  // Schema.org
  if (el.getAttribute('itemprop') === 'name') score += 50;

  // Visual prominence
  try {
    const style = window.getComputedStyle(el);
    const fontSize = parseFloat(style.fontSize);
    if (fontSize >= 24) score += 25;
    else if (fontSize >= 18) score += 15;

    const fontWeight = style.fontWeight;
    if (fontWeight >= 600 || fontWeight === 'bold') score += 10;
  } catch (e) {}

  // Position (product name usually near top)
  try {
    const rect = el.getBoundingClientRect();
    if (rect.top < 400) score += 15;
  } catch (e) {}

  // Penalties
  if (className.includes('related') || className.includes('similar') ||
      className.includes('recommend')) {
    score -= 50;
  }

  return score;
}

/**
 * Search DOM for elements containing a specific price value
 */
function findElementsWithPrice(priceValue) {
  const results = [];
  const priceStr = priceValue.toString();

  // Generate search patterns for the price in various international formats
  const patterns = [];

  const intPrice = Math.round(priceValue);
  const hasDecimals = priceValue !== intPrice;
  const decimalPart = hasDecimals ? (priceValue % 1).toFixed(2).substring(1) : ''; // ".00" or ".99"

  // Basic formats
  patterns.push(intPrice.toString()); // "4790"
  patterns.push(priceValue.toFixed(2)); // "4790.00"
  patterns.push(priceValue.toFixed(2).replace('.', ',')); // "4790,00"

  // Thousand separator formats (for prices >= 1000)
  if (intPrice >= 1000) {
    // Format with spaces: "4 790" / "4 790,00" / "4 790.00"
    const withSpaces = intPrice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    patterns.push(withSpaces);
    patterns.push(withSpaces + ',00');
    patterns.push(withSpaces + '.00');
    if (hasDecimals) {
      patterns.push(withSpaces + decimalPart);
      patterns.push(withSpaces + decimalPart.replace('.', ','));
    }

    // US format with comma thousands: "4,790" / "4,790.00"
    const withCommaThousands = intPrice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    patterns.push(withCommaThousands);
    patterns.push(withCommaThousands + '.00');
    if (hasDecimals) {
      patterns.push(withCommaThousands + decimalPart);
    }

    // German format with dot thousands: "4.790" / "4.790,00"
    const withDotThousands = intPrice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    patterns.push(withDotThousands);
    patterns.push(withDotThousands + ',00');
    if (hasDecimals) {
      patterns.push(withDotThousands + decimalPart.replace('.', ','));
    }
  }

  // Deduplicate
  const uniquePatterns = [...new Set(patterns)];

  // Search all text nodes
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    null,
    false
  );

  const seen = new Set();

  while (walker.nextNode()) {
    const textNode = walker.currentNode;
    const text = textNode.textContent || '';

    for (const pattern of uniquePatterns) {
      if (text.includes(pattern)) {
        let el = textNode.parentElement;

        // Walk up to find a meaningful container (not just a span inside span)
        while (el && ['SPAN', 'STRONG', 'B', 'EM'].includes(el.tagName) && el.parentElement) {
          const parent = el.parentElement;
          const parentText = parent.innerText || '';
          // If parent has roughly the same text, use parent
          if (parentText.length < text.length * 2) {
            el = parent;
          } else {
            break;
          }
        }

        if (el && !seen.has(el)) {
          seen.add(el);
          const score = scorePriceElement(el);
          results.push({
            element: el,
            selector: buildRobustSelector(el),
            score: score,
            text: el.innerText?.substring(0, 100) || '',
            matchedPattern: pattern
          });
        }
        break; // Found match for this text node
      }
    }
  }

  // Also check elements with data attributes
  document.querySelectorAll('[data-price], [data-product-price], [itemprop="price"]').forEach(el => {
    if (seen.has(el)) return;

    const content = el.getAttribute('content') || el.getAttribute('data-price') ||
                    el.getAttribute('data-product-price') || el.innerText || '';

    for (const pattern of uniquePatterns) {
      if (content.includes(pattern)) {
        seen.add(el);
        results.push({
          element: el,
          selector: buildRobustSelector(el),
          score: scorePriceElement(el) + 20, // Bonus for structured data
          text: el.innerText?.substring(0, 100) || content,
          matchedPattern: pattern
        });
        break;
      }
    }
  });

  // Sort by score (highest first)
  return results.sort((a, b) => b.score - a.score);
}

/**
 * Search DOM for elements containing a specific text (for product name)
 */
function findElementsWithText(searchText) {
  const results = [];
  const normalizedSearch = searchText.toLowerCase().trim();

  if (normalizedSearch.length < 3) return results;

  const seen = new Set();

  // Search in headings first (most likely to be product names)
  document.querySelectorAll('h1, h2, h3, [itemprop="name"], [class*="product-name"], [class*="product-title"]').forEach(el => {
    const text = (el.innerText || el.textContent || '').trim();
    const normalizedText = text.toLowerCase();

    if (normalizedText.includes(normalizedSearch) || normalizedSearch.includes(normalizedText)) {
      if (!seen.has(el)) {
        seen.add(el);
        results.push({
          element: el,
          selector: buildRobustSelector(el),
          score: scoreNameElement(el),
          text: text.substring(0, 150)
        });
      }
    }
  });

  // Also search all text nodes for exact matches
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    null,
    false
  );

  while (walker.nextNode()) {
    const textNode = walker.currentNode;
    const text = (textNode.textContent || '').trim();
    const normalizedText = text.toLowerCase();

    if (normalizedText.includes(normalizedSearch) && text.length < 200) {
      let el = textNode.parentElement;

      if (el && !seen.has(el)) {
        seen.add(el);
        results.push({
          element: el,
          selector: buildRobustSelector(el),
          score: scoreNameElement(el),
          text: text.substring(0, 150)
        });
      }
    }
  }

  return results.sort((a, b) => b.score - a.score);
}

/**
 * Search DOM for images with a specific URL
 */
function findElementsWithImage(imageUrl) {
  const results = [];

  if (!imageUrl) return results;

  // Normalize URL for comparison
  const normalizedUrl = imageUrl.toLowerCase().split('?')[0];

  document.querySelectorAll('img, [style*="background-image"], meta[property="og:image"], meta[name="twitter:image"]').forEach(el => {
    let elUrl = '';

    if (el.tagName === 'IMG') {
      elUrl = el.src || el.getAttribute('data-src') || '';
    } else if (el.tagName === 'META') {
      elUrl = el.content || '';
    } else {
      const style = el.style.backgroundImage || '';
      const match = style.match(/url\(['"]?([^'"]+)['"]?\)/);
      if (match) elUrl = match[1];
    }

    if (elUrl.toLowerCase().split('?')[0] === normalizedUrl) {
      results.push({
        element: el,
        selector: buildRobustSelector(el),
        score: 100,
        url: elUrl
      });
    }
  });

  return results;
}

/**
 * Main discovery function - finds selectors for corrected values
 */
function discoverSelectorsFromCorrections(originalData, correctedData) {
  const discoveries = {};

  console.log('[SAIVED Discovery] Analyzing corrections...', { originalData, correctedData });

  // Check price correction
  if (correctedData.unit_price != null &&
      correctedData.unit_price !== originalData.unit_price) {
    console.log('[SAIVED Discovery] Price was corrected:', originalData.unit_price, '→', correctedData.unit_price);

    const candidates = findElementsWithPrice(correctedData.unit_price);
    console.log('[SAIVED Discovery] Found price candidates:', candidates.length);

    if (candidates.length > 0) {
      discoveries.price = {
        corrected_value: correctedData.unit_price,
        original_value: originalData.unit_price,
        candidates: candidates.slice(0, 5).map(c => ({
          selector: c.selector,
          score: c.score,
          text: c.text,
          matched_pattern: c.matchedPattern
        }))
      };
      console.log('[SAIVED Discovery] Best price selector:', candidates[0].selector, 'score:', candidates[0].score);
    }
  }

  // Check name correction
  if (correctedData.name && correctedData.name !== originalData.name) {
    console.log('[SAIVED Discovery] Name was corrected:', originalData.name, '→', correctedData.name);

    const candidates = findElementsWithText(correctedData.name);

    if (candidates.length > 0) {
      discoveries.name = {
        corrected_value: correctedData.name,
        original_value: originalData.name,
        candidates: candidates.slice(0, 3).map(c => ({
          selector: c.selector,
          score: c.score,
          text: c.text
        }))
      };
      console.log('[SAIVED Discovery] Best name selector:', candidates[0].selector);
    }
  }

  // Check thumbnail correction
  if (correctedData.thumbnail_url &&
      correctedData.thumbnail_url !== originalData.thumbnail_url) {
    console.log('[SAIVED Discovery] Thumbnail was corrected');

    const candidates = findElementsWithImage(correctedData.thumbnail_url);

    if (candidates.length > 0) {
      discoveries.thumbnail_url = {
        corrected_value: correctedData.thumbnail_url,
        original_value: originalData.thumbnail_url,
        candidates: candidates.slice(0, 3).map(c => ({
          selector: c.selector,
          score: c.score,
          url: c.url
        }))
      };
    }
  }

  return discoveries;
}

// Try learned selector first, then fallback to heuristics
function tryLearnedSelector(field, fallbackFn) {
  const learnedSelector = learnedSelectors[field];
  if (learnedSelector) {
    const el = safeQuery(learnedSelector);
    if (el) {
      return { el, usedLearned: true, selector: learnedSelector };
    }
  }
  // Fallback to heuristic
  const result = fallbackFn();
  return { ...result, usedLearned: false };
}

function outerHtmlSample(el) {
  if (!el) return "";
  const html = el.outerHTML || "";
  // przytnij, żeby nie wysyłać kilometrowych stringów
  return html.length > 400 ? html.slice(0, 400) + "..." : html;
}

// ============================================================
// CATEGORY DETECTION FUNCTIONS
// ============================================================

/**
 * Extract category from JSON-LD structured data
 */
function extractJsonLdCategory() {
  const scripts = document.querySelectorAll('script[type="application/ld+json"]');
  for (const script of scripts) {
    try {
      const data = JSON.parse(script.textContent);
      // Handle @graph array or single object
      const items = data['@graph'] || [data];
      for (const item of items) {
        if (item['@type'] === 'Product' && item.category) {
          return item.category;
        }
        // Also check BreadcrumbList
        if (item['@type'] === 'BreadcrumbList' && item.itemListElement) {
          const breadcrumbs = item.itemListElement
            .sort((a, b) => (a.position || 0) - (b.position || 0))
            .map(el => el.name || el.item?.name || '')
            .filter(Boolean);
          if (breadcrumbs.length > 1) {
            return breadcrumbs.slice(1).join(' > '); // Skip "Home"
          }
        }
      }
    } catch (e) {
      // Invalid JSON, skip
    }
  }
  return null;
}

/**
 * Extract breadcrumbs from page navigation
 */
function extractBreadcrumbs() {
  const selectors = [
    '[aria-label="breadcrumb"] a',
    '[aria-label="breadcrumbs"] a',
    '[aria-label="Breadcrumb"] a',
    '.breadcrumb a', '.breadcrumbs a',
    '[itemtype*="BreadcrumbList"] a',
    'nav.breadcrumb a',
    '[data-testid="breadcrumb"] a',
    '.breadcrumb-item a',
    '[class*="breadcrumb"] a'
  ];

  for (const selector of selectors) {
    try {
      const links = document.querySelectorAll(selector);
      if (links.length > 1) {
        return Array.from(links)
          .map(el => el.textContent.trim())
          .filter(text => text && text.length > 1 && text.toLowerCase() !== 'home' && text.toLowerCase() !== 'strona główna');
      }
    } catch (e) {}
  }
  return [];
}

/**
 * Extract meaningful segments from URL path
 */
function extractUrlSegments() {
  const path = location.pathname;
  return path.split('/')
    .filter(seg => {
      if (!seg || seg.length < 3) return false;
      if (/^\d+$/.test(seg)) return false; // Pure numbers (IDs)
      if (/^[a-f0-9]{8,}$/i.test(seg)) return false; // Hashes
      if (seg.startsWith('p-') || seg.startsWith('product-')) return false; // Product prefixes
      return true;
    });
}

/**
 * Main category detection function
 * Analyzes page signals and maps to predefined categories
 */
function detectCategory(productName = '') {
  const signals = {
    jsonLd: extractJsonLdCategory(),
    breadcrumbs: extractBreadcrumbs(),
    urlSegments: extractUrlSegments(),
    productName: productName.toLowerCase()
  };

  // Combine all text for analysis
  const allText = [
    signals.jsonLd || '',
    ...signals.breadcrumbs,
    ...signals.urlSegments,
    signals.productName
  ].join(' ').toLowerCase();

  // Calculate score for each category
  const scores = {};

  for (const [categoryId, config] of Object.entries(CATEGORY_KEYWORDS)) {
    let score = 0;
    const matchedKeywords = [];

    for (const keyword of config.keywords) {
      const keywordLower = keyword.toLowerCase();
      if (allText.includes(keywordLower)) {
        score += config.weight;
        matchedKeywords.push(keyword);
      }
    }

    if (score > 0) {
      scores[categoryId] = {
        category: categoryId,
        score,
        confidence: Math.min(score / 3, 1), // Normalize to 0-1
        matchedKeywords,
        sources: []
      };

      // Track which sources contributed
      if (signals.jsonLd && matchedKeywords.some(k => signals.jsonLd.toLowerCase().includes(k.toLowerCase()))) {
        scores[categoryId].sources.push('json_ld');
        scores[categoryId].confidence = Math.min(scores[categoryId].confidence + 0.2, 1);
      }
      if (signals.breadcrumbs.some(b => matchedKeywords.some(k => b.toLowerCase().includes(k.toLowerCase())))) {
        scores[categoryId].sources.push('breadcrumbs');
        scores[categoryId].confidence = Math.min(scores[categoryId].confidence + 0.15, 1);
      }
      if (signals.urlSegments.some(s => matchedKeywords.some(k => s.toLowerCase().includes(k.toLowerCase())))) {
        scores[categoryId].sources.push('url');
        scores[categoryId].confidence = Math.min(scores[categoryId].confidence + 0.1, 1);
      }
      if (matchedKeywords.some(k => signals.productName.includes(k.toLowerCase()))) {
        scores[categoryId].sources.push('product_name');
      }
    }
  }

  // Sort by confidence
  const ranked = Object.values(scores)
    .sort((a, b) => b.confidence - a.confidence)
    .slice(0, 3); // Top 3

  console.log('[SAIVED Category] Detected categories:', ranked);
  console.log('[SAIVED Category] Signals:', signals);

  return {
    suggestions: ranked,
    signals
  };
}

function buildCssSelector(el) {
  if (!el || !el.tagName) return "";
  let path = [];
  let node = el;

  while (node && node.nodeType === 1 && path.length < 5) {
    let selector = node.tagName.toLowerCase();

    // Handle meta tags with identifying attributes
    if (selector === "meta") {
      const prop = node.getAttribute("property");
      const name = node.getAttribute("name");
      const httpEquiv = node.getAttribute("http-equiv");
      if (prop) {
        selector = `meta[property="${prop}"]`;
        path.unshift(selector);
        break; // meta with property is unique enough
      } else if (name) {
        selector = `meta[name="${name}"]`;
        path.unshift(selector);
        break;
      } else if (httpEquiv) {
        selector = `meta[http-equiv="${httpEquiv}"]`;
        path.unshift(selector);
        break;
      }
    }

    if (node.id) {
      selector += "#" + node.id;
      path.unshift(selector);
      break;
    } else {
      if (node.className && typeof node.className === "string") {
        const classes = node.className
          .split(/\s+/)
          .filter(Boolean)
          .slice(0, 2);
        if (classes.length) {
          selector += "." + classes.join(".");
        }
      }
      path.unshift(selector);
      node = node.parentElement;
    }
  }

  return path.join(" ");
}

function extractProductInfo() {
  const url = location.href;
  const domain = location.hostname;

  // Track which fields used learned selectors
  const usedLearnedFor = {};

  // --- NAZWA ---
  let name = "";
  let nameEl = null;

  const nameResult = tryLearnedSelector("name", () => {
    // Heuristic fallback for name
    let el =
      safeQuery('meta[property="og:title"]') ||
      safeQuery('meta[name="twitter:title"]');

    if (el && el.content) {
      return { el, value: el.content.trim() };
    }

    // weź h1 z największym font-size
    const h1s = Array.from(document.querySelectorAll("h1"));
    if (h1s.length) {
      let best = h1s[0];
      let bestSize = parseFloat(getComputedStyle(best).fontSize) || 0;
      for (const h of h1s) {
        const size = parseFloat(getComputedStyle(h).fontSize) || 0;
        if (size > bestSize) {
          best = h;
          bestSize = size;
        }
      }
      return { el: best, value: best.innerText.trim() };
    }

    return { el: null, value: "" };
  });

  nameEl = nameResult.el;
  usedLearnedFor.name = nameResult.usedLearned;

  if (nameResult.usedLearned && nameEl) {
    // Extract value from learned selector element
    name = nameEl.content || nameEl.innerText || "";
    name = name.trim();
  } else {
    name = nameResult.value || "";
  }

  // --- CENA ---
  let priceText = "";
  let priceEl = null;

  const priceResult = tryLearnedSelector("price", () => {
    // High-priority: structured data (very reliable, take first match)
    const structuredSelectors = [
      '[itemprop="price"]',
      '[data-price]'
    ];

    for (const sel of structuredSelectors) {
      const el = safeQuery(sel);
      if (el) {
        const text = (
          el.getAttribute("data-price") ||
          el.getAttribute("data-value") ||
          el.getAttribute("content") ||
          el.value ||
          el.innerText ||
          ""
        ).trim();
        if (text && (/[\d]+[.,]\d{2}/.test(text) || /^\d+$/.test(text))) {
          return { el, value: text };
        }
      }
    }

    // Lower-priority: class-based selectors — score ALL candidates, pick best
    const candidates = [];
    const classSelectors = ['[class*="price"]', '[class*="Price"]'];

    for (const sel of classSelectors) {
      try {
        const elements = document.querySelectorAll(sel);
        for (const el of elements) {
          const text = (el.innerText || "").trim();
          // Skip if no digits, too long, or contains % (discount percentages)
          if (!text || text.length > 30 || !(/\d/.test(text)) || text.includes('%')) continue;
          // Must look like a price
          if (!(/[\d]+[.,]\d{2}/.test(text) || /^\d+$/.test(text.replace(/[^\d]/g, '')))) continue;

          const score = scorePriceElement(el);
          candidates.push({ el, value: text, score });
        }
      } catch (e) {}
    }

    if (candidates.length > 0) {
      candidates.sort((a, b) => b.score - a.score);
      return { el: candidates[0].el, value: candidates[0].value };
    }

    return { el: null, value: "" };
  });

  priceEl = priceResult.el;
  usedLearnedFor.price = priceResult.usedLearned;

  if (priceResult.usedLearned && priceEl) {
    // Try multiple ways to extract price value from the element
    priceText = (
      priceEl.getAttribute("data-price") ||    // data-price attribute (beliani.pl uses this)
      priceEl.getAttribute("data-value") ||    // data-value attribute
      priceEl.getAttribute("content") ||       // meta tags
      priceEl.value ||                         // input elements
      priceEl.innerText ||                     // regular elements
      ""
    ).trim();
  } else {
    priceText = priceResult.value || "";
  }

  let priceNumber = null;
  if (priceText) {
    priceNumber = parsePrice(priceText);
  }

  // --- MINIATURKA ---
  let thumbUrl = "";
  let thumbEl = null;

  const thumbResult = tryLearnedSelector("thumbnail_url", () => {
    // Heuristic fallback for thumbnail
    let el =
      safeQuery('meta[property="og:image"]') ||
      safeQuery('meta[name="twitter:image"]');

    if (el && el.content) {
      return { el, value: el.content.trim() };
    }

    const imgs = Array.from(document.images || []);
    if (imgs.length) {
      // weź największe img
      let best = imgs[0];
      let bestArea = best.naturalWidth * best.naturalHeight;
      for (const img of imgs) {
        const area = img.naturalWidth * img.naturalHeight;
        if (area > bestArea) {
          best = img;
          bestArea = area;
        }
      }
      return { el: best, value: best.src || "" };
    }

    return { el: null, value: "" };
  });

  thumbEl = thumbResult.el;
  usedLearnedFor.thumbnail = thumbResult.usedLearned;

  if (thumbResult.usedLearned && thumbEl) {
    thumbUrl = thumbEl.content || thumbEl.src || "";
    thumbUrl = thumbUrl.trim();
  } else {
    thumbUrl = thumbResult.value || "";
  }

  const selectors = {};
  const htmlSamples = {};

  if (nameEl) {
    selectors.name = nameResult.selector || buildCssSelector(nameEl);
    htmlSamples.name = outerHtmlSample(nameEl);
  }
  if (priceEl) {
    selectors.price = priceResult.selector || buildCssSelector(priceEl);
    htmlSamples.price = outerHtmlSample(priceEl);
  }
  if (thumbEl) {
    selectors.thumbnail = thumbResult.selector || buildCssSelector(thumbEl);
    htmlSamples.thumbnail = outerHtmlSample(thumbEl);
  }

  // Determine engine type based on whether learned selectors were used
  const hasLearned = Object.values(usedLearnedFor).some(v => v);
  const engine = hasLearned ? "learned-v1" : "heuristic-v1";

  // --- CATEGORY DETECTION ---
  const categoryDetection = detectCategory(name);

  const product = {
    name: name || "",
    unit_price: priceNumber,
    currency: "PLN",
    thumbnail_url: thumbUrl || "",
    external_url: url
  };

  const capture_context = {
    url,
    domain,
    selectors,
    html_samples: htmlSamples,
    engine,
    used_learned: usedLearnedFor,
    category_suggestions: categoryDetection.suggestions,
    category_signals: categoryDetection.signals
  };

  return { product, capture_context };
}

// ============================================================
// PRICE PICKER MODE
// ============================================================

function startPricePickerMode() {
  if (pricePickerActive) return;
  pricePickerActive = true;

  // Create overlay with instruction bar
  pricePickerOverlay = document.createElement("div");
  pricePickerOverlay.id = "saived-price-picker-overlay";
  pricePickerOverlay.innerHTML = `
    <div class="saived-picker-bar">
      <span class="saived-picker-icon">🎯</span>
      <span class="saived-picker-text">Kliknij na cenę produktu</span>
      <button class="saived-picker-cancel">✕ Anuluj</button>
    </div>
    <style>
      #saived-price-picker-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 2147483647;
        pointer-events: none;
      }

      .saived-picker-bar {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: linear-gradient(135deg, #111827, #1f2937);
        color: white;
        padding: 12px 20px;
        display: flex;
        align-items: center;
        gap: 12px;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        font-size: 14px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        pointer-events: auto;
        z-index: 2147483647;
      }

      .saived-picker-icon {
        font-size: 20px;
      }

      .saived-picker-text {
        flex: 1;
        font-weight: 500;
      }

      .saived-picker-cancel {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white;
        padding: 6px 14px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 13px;
        font-weight: 500;
        transition: all 0.15s;
      }

      .saived-picker-cancel:hover {
        background: rgba(255, 255, 255, 0.2);
      }

      .saived-price-highlight {
        outline: 3px solid #10b981 !important;
        outline-offset: 2px !important;
        background: rgba(16, 185, 129, 0.1) !important;
        cursor: crosshair !important;
      }
    </style>
  `;

  document.body.appendChild(pricePickerOverlay);

  // Add event listeners
  document.addEventListener("mouseover", handlePickerHover, true);
  document.addEventListener("mouseout", handlePickerOut, true);
  document.addEventListener("click", handlePickerClick, true);
  document.addEventListener("keydown", handlePickerEscape, true);

  pricePickerOverlay.querySelector(".saived-picker-cancel")
    .addEventListener("click", cancelPricePicker);

  console.log("[SAIVED] Price picker mode started");
}

function handlePickerHover(e) {
  if (!pricePickerActive) return;
  if (e.target.closest("#saived-price-picker-overlay")) return;

  // Check if element looks like it contains a price
  if (looksLikePrice(e.target)) {
    e.target.classList.add("saived-price-highlight");
  }
}

function handlePickerOut(e) {
  e.target.classList.remove("saived-price-highlight");
}

function handlePickerClick(e) {
  if (!pricePickerActive) return;
  if (e.target.closest("#saived-price-picker-overlay")) return;

  e.preventDefault();
  e.stopPropagation();

  const text = (e.target.innerText || "").trim();
  const price = parsePrice(text);
  const selector = buildRobustSelector(e.target);

  console.log("[SAIVED] Price selected:", { text, price, selector });

  // Send result via postMessage to iframe (if available)
  if (saivedIframe) {
    saivedIframe.contentWindow.postMessage({
      type: "SAIVED_PRICE_PICKED",
      price,
      rawText: text,
      selector
    }, "*");
    cleanupPricePicker();
    showSaived();
  } else {
    // Fallback: save to storage for native popup mode
    browserApi.storage.local.get("saived_price_picker").then(data => {
      const picker = data.saived_price_picker || {};
      picker.status = "completed";
      picker.result = { price, rawText: text, selector };
      browserApi.storage.local.set({ saived_price_picker: picker });
      showPickerSuccessToast(price);
    });
    cleanupPricePicker();
  }
}

function showPickerSuccessToast(price) {
  const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
  const shortcut = isMac ? '⌥⇧S' : 'Alt+Shift+S';

  const toast = document.createElement('div');
  toast.id = 'saived-picker-toast';
  toast.innerHTML = `
    <style>
      #saived-picker-toast {
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: linear-gradient(135deg, #059669, #10b981);
        color: white;
        padding: 14px 24px;
        border-radius: 12px;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        font-size: 14px;
        box-shadow: 0 8px 30px rgba(5, 150, 105, 0.4);
        z-index: 2147483647;
        display: flex;
        flex-direction: column;
        gap: 4px;
        animation: saived-toast-in 0.3s ease;
      }
      @keyframes saived-toast-in {
        from { opacity: 0; transform: translateX(-50%) translateY(-20px); }
        to { opacity: 1; transform: translateX(-50%) translateY(0); }
      }
      #saived-picker-toast .toast-title {
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 8px;
      }
      #saived-picker-toast .toast-hint {
        font-size: 13px;
        opacity: 0.9;
      }
      #saived-picker-toast kbd {
        background: rgba(255,255,255,0.2);
        padding: 2px 6px;
        border-radius: 4px;
        font-family: inherit;
      }
    </style>
    <span class="toast-title">
      <span>✓</span>
      <span>Cena ${price != null ? price.toFixed(2) + ' zł' : ''} wybrana!</span>
    </span>
    <span class="toast-hint">Otwórz wtyczkę: <kbd>${shortcut}</kbd></span>
  `;

  document.body.appendChild(toast);

  // Auto-remove after 4s
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-50%) translateY(-20px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function handlePickerEscape(e) {
  if (e.key === "Escape") {
    cancelPricePicker();
  }
}

function looksLikePrice(el) {
  if (!el || !el.innerText) return false;

  const text = (el.innerText || "").trim();

  // Skip if too long or empty
  if (!text || text.length > 30) return false;

  // Skip the picker bar itself
  if (el.closest("#saived-price-picker-overlay")) return false;

  // Must contain at least one digit
  if (!/\d/.test(text)) return false;

  // Common price patterns
  return /\d+([.,]\d{1,2})?/.test(text);
}

function cancelPricePicker() {
  console.log("[SAIVED] Price picker cancelled");

  if (saivedIframe) {
    cleanupPricePicker();
    showSaived();
  } else {
    browserApi.storage.local.get("saived_price_picker").then(data => {
      const picker = data.saived_price_picker || {};
      picker.status = "cancelled";
      browserApi.storage.local.set({ saived_price_picker: picker });
    });
    cleanupPricePicker();
  }
}

function cleanupPricePicker() {
  pricePickerActive = false;

  // Remove event listeners
  document.removeEventListener("mouseover", handlePickerHover, true);
  document.removeEventListener("mouseout", handlePickerOut, true);
  document.removeEventListener("click", handlePickerClick, true);
  document.removeEventListener("keydown", handlePickerEscape, true);

  // Remove highlights
  document.querySelectorAll(".saived-price-highlight")
    .forEach(el => el.classList.remove("saived-price-highlight"));

  // Remove overlay
  if (pricePickerOverlay) {
    pricePickerOverlay.remove();
    pricePickerOverlay = null;
  }

  console.log("[SAIVED] Price picker cleaned up");
}

// ============================================================
// IMAGE PICKER MODE
// ============================================================

function startImagePickerMode() {
  if (imagePickerActive) return;
  imagePickerActive = true;

  imagePickerOverlay = document.createElement("div");
  imagePickerOverlay.id = "saived-image-picker-overlay";
  imagePickerOverlay.innerHTML = `
    <div class="saived-picker-bar">
      <span class="saived-picker-icon">🎯</span>
      <span class="saived-picker-text">Kliknij na zdjęcie produktu</span>
      <button class="saived-picker-cancel">✕ Anuluj</button>
    </div>
    <style>
      #saived-image-picker-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 2147483647;
        pointer-events: none;
      }

      #saived-image-picker-overlay .saived-picker-bar {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: linear-gradient(135deg, #111827, #1f2937);
        color: white;
        padding: 12px 20px;
        display: flex;
        align-items: center;
        gap: 12px;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        font-size: 14px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        pointer-events: auto;
        z-index: 2147483647;
      }

      #saived-image-picker-overlay .saived-picker-icon {
        font-size: 20px;
      }

      #saived-image-picker-overlay .saived-picker-text {
        flex: 1;
        font-weight: 500;
      }

      #saived-image-picker-overlay .saived-picker-cancel {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white;
        padding: 6px 14px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 13px;
        font-weight: 500;
        transition: all 0.15s;
      }

      #saived-image-picker-overlay .saived-picker-cancel:hover {
        background: rgba(255, 255, 255, 0.2);
      }

      .saived-image-highlight {
        outline: 3px solid #10b981 !important;
        outline-offset: 2px !important;
        cursor: crosshair !important;
      }
    </style>
  `;

  document.body.appendChild(imagePickerOverlay);

  document.addEventListener("mouseover", handleImagePickerHover, true);
  document.addEventListener("mouseout", handleImagePickerOut, true);
  document.addEventListener("click", handleImagePickerClick, true);
  document.addEventListener("keydown", handleImagePickerEscape, true);

  imagePickerOverlay.querySelector(".saived-picker-cancel")
    .addEventListener("click", cancelImagePicker);

  console.log("[SAIVED] Image picker mode started");
}

function looksLikeImage(el) {
  if (!el) return false;

  // Skip elements inside SAIVED host
  if (el.closest("#saived-host") || el.closest("#saived-image-picker-overlay")) return false;

  // Check if element is an img with src
  if (el.tagName === "IMG" && (el.src || el.srcset)) {
    const rect = el.getBoundingClientRect();
    return rect.width >= 50 && rect.height >= 50;
  }

  // Check for background-image
  try {
    const style = window.getComputedStyle(el);
    const bgImage = style.backgroundImage;
    if (bgImage && bgImage !== "none") {
      const rect = el.getBoundingClientRect();
      return rect.width >= 50 && rect.height >= 50;
    }
  } catch (e) {}

  // Check for picture > source elements
  if (el.tagName === "PICTURE") {
    const rect = el.getBoundingClientRect();
    return rect.width >= 50 && rect.height >= 50;
  }

  return false;
}

function getImageUrl(el) {
  if (el.tagName === "IMG") {
    // Prefer srcset highest resolution
    if (el.srcset) {
      const candidates = el.srcset.split(",").map(s => s.trim().split(/\s+/));
      if (candidates.length > 0) {
        return candidates[candidates.length - 1][0];
      }
    }
    return el.src;
  }

  // Background image
  try {
    const style = window.getComputedStyle(el);
    const bgImage = style.backgroundImage;
    const match = bgImage.match(/url\(['"]?([^'"]+)['"]?\)/);
    if (match) return match[1];
  } catch (e) {}

  // Picture element
  if (el.tagName === "PICTURE") {
    const source = el.querySelector("source");
    if (source && source.srcset) {
      return source.srcset.split(",")[0].trim().split(/\s+/)[0];
    }
    const img = el.querySelector("img");
    if (img) return img.src;
  }

  return null;
}

function handleImagePickerHover(e) {
  if (!imagePickerActive) return;
  if (e.target.closest("#saived-image-picker-overlay")) return;

  if (looksLikeImage(e.target)) {
    e.target.classList.add("saived-image-highlight");
  }
}

function handleImagePickerOut(e) {
  e.target.classList.remove("saived-image-highlight");
}

function handleImagePickerClick(e) {
  if (!imagePickerActive) return;
  if (e.target.closest("#saived-image-picker-overlay")) return;

  if (!looksLikeImage(e.target)) return;

  e.preventDefault();
  e.stopPropagation();

  const url = getImageUrl(e.target);
  const selector = buildRobustSelector(e.target);

  console.log("[SAIVED] Image selected:", { url, selector });

  if (saivedIframe && url) {
    saivedIframe.contentWindow.postMessage({
      type: "SAIVED_IMAGE_PICKED",
      url,
      selector
    }, "*");
  }

  cleanupImagePicker();
  showSaived();
}

function handleImagePickerEscape(e) {
  if (e.key === "Escape") {
    cancelImagePicker();
  }
}

function cancelImagePicker() {
  console.log("[SAIVED] Image picker cancelled");
  cleanupImagePicker();
  showSaived();
}

function cleanupImagePicker() {
  imagePickerActive = false;

  document.removeEventListener("mouseover", handleImagePickerHover, true);
  document.removeEventListener("mouseout", handleImagePickerOut, true);
  document.removeEventListener("click", handleImagePickerClick, true);
  document.removeEventListener("keydown", handleImagePickerEscape, true);

  document.querySelectorAll(".saived-image-highlight")
    .forEach(el => el.classList.remove("saived-image-highlight"));

  if (imagePickerOverlay) {
    imagePickerOverlay.remove();
    imagePickerOverlay = null;
  }

  console.log("[SAIVED] Image picker cleaned up");
}

browserApi.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Handle toggle from background.js (icon click)
  if (message && message.type === "SAIVED_TOGGLE") {
    if (!saivedHost) {
      createIframeHost();
      showSaived();
    } else {
      toggleSaived();
    }
    sendResponse({ ok: true });
    return true;
  }

  // Handle hide from background.js (before side panel opens)
  if (message && message.type === "SAIVED_HIDE") {
    closeSaived();
    sendResponse({ ok: true });
    return true;
  }

  if (message && message.type === "SAIVED_SCRAPE_PAGE") {
    try {
      // Accept learned selectors from popup (if provided)
      if (message.learnedSelectors) {
        learnedSelectors = message.learnedSelectors;
        console.log("[SAIVED] Using learned selectors:", learnedSelectors);
      } else {
        learnedSelectors = {};
      }

      const data = extractProductInfo();
      sendResponse({ ok: true, data });
    } catch (e) {
      console.error("[SAIVED] błąd extractProductInfo:", e);
      sendResponse({ ok: false, error: String(e) });
    }
    return true; // async
  }

  // Handle discovery request - search DOM for corrected values
  if (message && message.type === "SAIVED_DISCOVER_SELECTORS") {
    try {
      const { originalData, correctedData } = message;
      const discoveries = discoverSelectorsFromCorrections(originalData, correctedData);
      sendResponse({ ok: true, discoveries });
    } catch (e) {
      console.error("[SAIVED] błąd discoverSelectors:", e);
      sendResponse({ ok: false, error: String(e) });
    }
    return true;
  }

  // Handle price picker start request
  if (message && message.type === "SAIVED_START_PRICE_PICKER") {
    startPricePickerMode();
    sendResponse({ ok: true });
    return true;
  }
});